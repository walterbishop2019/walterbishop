import urllib, urllib2,re

import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
import sys

from urllib2 import Request, urlopen, URLError, HTTPError
import requests

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)




def addMenuitem(url, li, folder):
    return xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=folder)


def endMenu():
    xbmcplugin.endOfDirectory(addon_handle)

def read(url):
    opener = urllib2.build_opener()
    opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.71 Safari/537.36')]
    response = opener.open(url)
    data = response.read()

    return data

def menu():
    fanart = 'http://darkelite.ml/img/fondo.jpg'
    url = build_url({'mode': 'blanco1'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Ultimos Capitulos Actualizados[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco4', 'direccion': 'https://seriesblanco.com'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Capitulos Estrenados Recientemente[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco5', 'direccion': 'https://seriesblanco.com'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Series mas Vistas en Series Blanco[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco6', 'direccion': 'https://seriesblanco.com'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Ultimas Series Agregadas[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco7', 'direccion': 'https://seriesblanco.com', 'pagina': 'pagina=1'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Listado de Series[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco8'})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Buscar Series en Series Blanco[/B][/COLOR]', iconImage=thumbnail,
                          thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)


def capactualizados():
    web = 'https://seriesblanco.com'
    data = read(web)
    pattern = '(itemprop.*?href.*?\/.*\n.*?image.*?src.*?title.*\>)'
    matches = re.findall(pattern, data, re.IGNORECASE)
    for match in matches:
        pattern = 'title\=\'(.*?)\''
        title = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=(.*?) t'
        thumbnail = re.findall(pattern, match, re.MULTILINE)[0]
        thumbnail = thumbnail.replace("\'", "")
        thumbnail = thumbnail.replace("\"", "")

        pattern = 'href\=(.*?)\>'
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = url.replace("\"", "")
        url = url.replace("\'", "")
        url = web + url

        fanart = 'http://darkelite.ml/img/fondo.jpg'

        url = build_url({'mode': 'blanco2', 'thumbnail': thumbnail, 'direccion': url})
        li = xbmcgui.ListItem(title, iconImage=thumbnail,
                              thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)



def capitulos(url,thumbnail,web2):
    data = read(url)
    pattern = '(table\-hover.*?href.*?btn\-rounded.*?\/a)'
    matches = re.findall(pattern, data, re.IGNORECASE)

    try:
        fanart = re.findall('og\:image\'.*?\'(.*?)\'', data, re.MULTILINE)[0]
    except Exception as fanart:
        fanart = 'http://darkelite.ml/img/fondo.jpg'
    except KeyError as fanart:
        fanart = 'http://darkelite.ml/img/fondo.jpg'
    except:
        fanart = 'http://darkelite.ml/img/fondo.jpg'



    info = re.findall('h4.*?br(.*)', data, re.MULTILINE)[0]
    for match in matches:

        pattern = '.*?btn\-lg.*?\>(.*?)\<\/a'
        title = re.findall(pattern, match, re.MULTILINE)[0]
        title = title.replace("<span itemprop='episodeNumber'>","")
        title =title.replace("</span>","")

        thumbnail = thumbnail

        fanart = fanart
        info = info

        pattern = 'href\=(.*?) t'
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = url.replace("\"", "")
        url = url.replace("\'", "")
        url = web2 + url

        url = build_url({'mode': 'blanco3', 'thumbnail': thumbnail, 'direccion': url, 'fanart': fanart, 'foldername': title, 'info': info})
        li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": info})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)

def servidores(web,fanart,info,thumbnail):
    data = read(web)
    web2 = 'https://seriesblanco.com'
    pattern = '(src\=.*\n.*\n.*\n.*\n.*\n.*\n.*grid.*\n.*\n.*?href.*\n.*?src.*\/a)'
    matches = re.findall(pattern, data, re.IGNORECASE)
    for match in matches:

        pattern = 'src.*servidores(.*?)\''
        servidor = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=\".*?banderas(.*?)\"'
        idioma = re.findall(pattern, match, re.MULTILINE)[0]
        if 'vo.png' in idioma:
            idioma = ' English'
        elif 'vos.png' in idioma:
            idioma = ' Subtitulado'
        elif 'es.png' in idioma:
            idioma = ' Esp'
        elif 'la.png' in idioma:
            idioma = ' Latino'
        elif 'jpsub.png' in idioma:
            idioma = ' Subtitulado'

        fanart = fanart
        info = info
        thumbnail = thumbnail

        pattern = 'href.\"(.*?)\"'
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = web2 + url

        if 'gamovideo' in servidor:
            title = 'Servidor Gamovideo ' + ' idioma ' + idioma
            url = build_url({'mode': 'play2', 'playlink': url})
            li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
            li.setInfo("video", {"Title": title, "FileName": title, "Plot": info})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('fanart_image', fanart)
            addMenuitem(url, li, False)

        elif 'openload' in servidor:
            title = 'Servidor Openload ' + ' idioma ' + idioma
            url = build_url({'mode': 'play2', 'playlink': url})
            li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
            li.setInfo("video", {"Title": title, "FileName": title, "Plot": info})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('fanart_image', fanart)
            addMenuitem(url, li, False)

        elif 'streamango' in servidor:
            title = 'Servidor StreaMango ' + ' idioma ' + idioma
            url = build_url({'mode': 'play2', 'playlink': url})
            li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
            li.setInfo("video", {"Title": title, "FileName": title, "Plot": info})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('fanart_image', fanart)
            addMenuitem(url, li, False)

        elif 'clipwatching' in servidor:
            title = 'Servidor ClipWatching ' + ' idioma ' + idioma
            url = build_url({'mode': 'play2', 'playlink': url})
            li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
            li.setInfo("video", {"Title": title, "FileName": title, "Plot": info})
            li.setProperty('IsPlayable', 'true')
            li.setProperty('fanart_image', fanart)
            addMenuitem(url, li, False)

def cap_Estreno(web):
    data = read(web)
    pattern = '(alt\=.*?href.*\n.*?tooltip.*?src.*title.*\/\>)'
    matches = re.findall(pattern, data, re.IGNORECASE)
    for match in matches:
        pattern = 'alt\=\"(.*?)\" \/\>'
        title = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=\'(.*?)\''
        thumbnail = re.findall(pattern, match, re.MULTILINE)[0]

        fanart = 'http://darkelite.ml/img/fondo.jpg'

        info = 'Disfruta tus Series Favoritas por Fusion Request'

        pattern = 'href\=\"(.*?)\"'
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = web + url

        url = build_url(
            {'mode': 'blanco3', 'thumbnail': thumbnail, 'direccion': url, 'fanart': fanart, 'foldername': title,
             'info': info})
        li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": info})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)

def mas_Vistas():
    web = args['direccion'][0]
    data = read(web)
    pattern = '(href.*\n.*?src.*?title.*?alt.*?title)'
    matches = re.findall(pattern, data, re.IGNORECASE)
    for match in matches:
        pattern = 'alt\=\'(.*?)\''
        title = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=\'(.*?)\''
        thumbnail = re.findall(pattern, match, re.MULTILINE)[0]

        fanart = 'http://darkelite.ml/img/fondo.jpg'

        info = 'Disfruta tus Series Favoritas por Fusion Request'

        pattern = 'href\=\'(.*?)\''
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = web + url

        url = build_url({'mode': 'blanco2', 'thumbnail': thumbnail, 'direccion': url})
        li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": info})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)


def ultimas_Agregadas(web):
    web2 = 'https://seriesblanco.com/fichas_creadas/'
    data = read(web2)
    pattern = '(href.*\n.*?src.*?title.*\n.*\n.*\n.*?\<p\>.*?\<\/p\>)'
    matches = re.findall(pattern, data, re.IGNORECASE)
    for match in matches:
        pattern = 'title?\=\'(.*?)\''
        title = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=\'(.*?)\''
        thumbnail = re.findall(pattern, match, re.MULTILINE)[0]

        fanart = 'http://darkelite.ml/img/fondo.jpg'

        pattern = '\<p\>(.*?)\<\/p\>'
        info = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'href\=\'(.*?)\''
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = web + url

        url = build_url({'mode': 'blanco2', 'thumbnail': thumbnail, 'direccion': url})
        li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": info})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)


def listado(web,web2,pagina):

    web3 = web2+pagina
    data = read(web3)
    pattern2 = '.*href=\"\?(.*?)\"\>\>\>'
    sigpagina = re.findall(pattern2,data,re.MULTILINE)[0]
    pattern = '(href\=.*\n.*?src.*?title.*)'
    matches = re.findall(pattern,data,re.IGNORECASE)
    for match in matches:
        pattern = 'title?\=\'(.*?)\''
        title = re.findall(pattern, match, re.MULTILINE)[0]

        pattern = 'src\=(.*?) ti'
        thumbnail = re.findall(pattern, match, re.MULTILINE)[0]
        thumbnail = thumbnail.replace("\"","")
        thumbnail = thumbnail.replace("\'", "")

        fanart = 'http://darkelite.ml/img/fondo.jpg'


        info = 'Listado Completo de Series Blanco'

        pattern = 'href\=\'(.*?)\''
        url = re.findall(pattern, match, re.MULTILINE)[0]
        url = web + url

        url = build_url({'mode': 'blanco2', 'thumbnail': thumbnail, 'direccion': url})
        li = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
        li.setInfo("video", {"Plot": info})
        li.setProperty('fanart_image', fanart)
        addMenuitem(url, li, True)

    fanart = 'http://darkelite.ml/img/fondo.jpg'
    url = build_url({'mode': 'blanco7', 'direccion': 'https://seriesblanco.com', 'pagina': sigpagina})
    thumbnail = 'http://pikilikilinks.esy.es/Archivos/Series%20Blanco.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Siguiente Pagina[/B][/COLOR]', iconImage=thumbnail,thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco'})
    li = xbmcgui.ListItem('[COLOR green][B]Regresar al Menu Ppal de Series Blanco[/B][/COLOR]', iconImage=thumbnail,thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)


def busqueda(criterio):
    url = 'https://seriesblanco.com/finder.php'
    opener = urllib2.build_opener()
    datos = urllib.urlencode({'query': criterio})
    opener.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.71 Safari/537.36')]
    response = opener.open(url, datos)
    data = response.read()
    return  data