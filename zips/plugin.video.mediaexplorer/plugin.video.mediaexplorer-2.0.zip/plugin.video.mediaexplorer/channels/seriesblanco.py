# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://seriesblanco.org/'

LNG = Languages({
    Languages.es: ['es'],
    Languages.sub_es: ['sub'],
    Languages.la: ['la'],
    Languages.en: ['en']
})

QLT = Qualities({
    Qualities.hd_full: ['1080p'],
    Qualities.hd: ['720p', 'micro-hd-720p'],
    Qualities.sd: ['360p', '480p']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="content",
        label="Nuevas series",
        url=HOST + "/ultimas-series/",
        type="item",
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="tvshows_az",
        label="Listado alfabético",
        type="item",
        url=HOST
    ))


    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        category='tvshow',
        content_type='tvshows'
    ))

    return itemlist


def content(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = HOST + "/ultimas-series-anadidas/"

    data = downloadpage(item.url)
    logger.debug(data)
    if item.action == 'search':
        patron = '<li\s*style="display:\s*block.*?<a\s*href="([^"]+)">.*?src="([^"]+)".*?data-original-title="([^"]+)'
    else:
        patron = '<li\s*style="display:\s*block.*?'
        if '/lista-de-series/' in item.url:
            patron = '<div\s*style="float:left;width:\s*50%;text-align:center;padding-left:15px">'
        patron += '<a\s*href="([^"]+)">.*?data-lazy-src="([^"]+)".*?data-original-title="([^"]+)">'

    for url, poster, title in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            action='seasons',
            type = 'tvshow',
            content_type = 'seasons',
            tvshowtitle = title,
            label = title,
            url=url,
            poster=poster))

    next_url= scrapertools.find_single_match(data, '<a\s*class="next\s*page-numbers"\s*href="([^"]+)')
    if next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def tvshows_az(item):
    logger.trace()
    itemlist = list()

    for letra in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        itemlist.append(item.clone(
            action="content",
            label=letra,
            type="item",
            content_type='tvshows',
            url=HOST + "/lista-de-series/%s/" % letra
        ))

    return itemlist


def search(item):
    logger.trace()
    item.url = "%s?s=%s&post_type=ficha" % (HOST, item.query.replace(" ", "+"))
    item.category = 'tvshow'

    return content(item)


def seasons(item):
    logger.trace()
    itemlist = list()

    data = downloadpage(item.url)

    if not item.plot:
        item.plot = scrapertools.find_single_match(data,
                                                   '<div role="tabpanel" class="tab-pane" id="profile2">([^<]+)')

    patron = '<h1 class="panel-title">.*?<span itemprop="seasonNumber".*?Temporada (\d+)'
    for num_season in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action="episodes",
            season=int(num_season),
            type='season',
            plot=item.plot,
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()
    item.thumb = ''

    data = downloadpage(item.url)

    inc = []
    patron = '<tr\s*class="table-hover"><td><a\s*href="([^"]+)".*?"episodeNumber">([^<]+)<(.*?)</td></tr>'
    for url, season_and_episode, langs in scrapertools.find_multiple_matches(data, patron):
        if url in inc:
            continue

        inc.append(url)
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode)

        if item.season == num_season:
            itemlist.append(item.clone(
                title=item.tvshowtitle,
                url=url,
                action="findvideos",
                episode=num_episode,
                lang=[LNG.get(l) for l in scrapertools.find_multiple_matches(langs, 'data-lazy-src=".*?/language/([^\.]+)\.png"')],
                type='episode',
                content_type='servers'
            ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()
    inc = []

    data = downloadpage(item.url)

    patron = '<tr\s*class="odd">.*?data-lazy-src=".*?/language/([^\.]+)\.png".*?data-enlace="([^"]+).*?<td>([^<]+).*?data-tipo="([^"]+)'
    for lang, url, qlt, tipo in scrapertools.find_multiple_matches(data, patron):
        if url in inc:
            continue

        inc.append(url)
        itemlist.append(item.clone(
            url=url,
            action='play',
            type='server',
            lang=LNG.get(lang),
            quality=QLT.get(qlt.lower().replace('p hd', 'p')),
            stream=('online' == tipo)
        ))

    return servertools.get_servers_itemlist(itemlist)


def downloadpage(*args, **kwargs):
    data = httptools.downloadpage(*args, **kwargs).data
    return re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
