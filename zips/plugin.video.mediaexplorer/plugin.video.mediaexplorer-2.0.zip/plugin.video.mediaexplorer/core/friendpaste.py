# -*- coding: utf-8 -*-
from core.libs import *
from six.moves.urllib_error import HTTPError

FP_URL = 'https://friendpaste.com'


def create(text, code="", title="", language="text", privacy="private", json=False):
    logger.trace()
    reason = 'Unknown error'
    try:
        code = code if code else int(time.time())
        payload = {
            "paste_snippet": text,
            "paste_language": language,
            "paste_title": title,
            "paste_code": code,
            "paste_privacy": privacy,  # "open",  'public', 'private'
            "paste_password": code,  # No funciona
            "psubmit": "Submit post"
        }

        data = httptools.downloadpage('%s/' % FP_URL, payload, headers={'Accept': 'application/json'}).data

        if scrapertools.find_single_match(data, '<h2 class="errors">Something was wrong!</h2>'):
            data = scrapertools.find_single_match(data, '<ul class="errors">(.*?)<div')
            t = '| '.join(scrapertools.find_multiple_matches(data, '<ul><li>([^<]+)</li></ul>'))
            reason = t if t else reason
            raise ()

        else:
            data = jsontools.load_json(data)
            if not lock(data['id'], code):
                raise ()

        return data if json else {'reason': None, 'id': data['id'], 'snippet': data['snippet']}

    except HTTPError as e:
        return {'id': None, 'reason': '%s %s' % (e.code, e.msg), 'snippet': None}

    except Exception:
        return {'id': None, 'reason': reason, 'snippet': None}


def read(_id, json=False):
    logger.trace()
    try:
        data = httptools.downloadpage('%s/%s' % (FP_URL, _id), headers={'Accept': 'application/json'}).data
        data = jsontools.load_json(data)

        return data if json else {'reason': None, 'id': data['id'], 'snippet': data['snippet']}
    except Exception:
        return {'id': None, 'reason': 'Unknown', 'snippet': None}


def update(_id, text, code="", title="", language="text", json=False):
    logger.trace()
    reason = 'Unknown error'
    try:
        if code and not unlock(_id, code):
            reason = 'Impossible to unlock'
            raise Exception()

        payload = {
            'paste_snippet': text,
            'paste_language': language,
            'paste_title': title,
            "psubmit": "Submit post"
        }

        data = httptools.downloadpage('%s/%s/edit' % (FP_URL, _id), payload, headers={'Accept': 'application/json'}).data

        if scrapertools.find_single_match(data, '<h2 class="errors">Something was wrong!</h2>'):
            data = scrapertools.find_single_match(data, '<ul class="errors">(.*?)<h2>Edit')
            t = '| '.join(scrapertools.find_multiple_matches(data, '<ul><li>([^<]+)</li></ul>'))
            reason = t if t else reason
            raise Exception()
        else:
            data = jsontools.load_json(data)
            return data if json else {'reason': None, 'id': data['id'], 'snippet': data['snippet']}
    except Exception:
        return {'id': None, 'reason': reason, 'snippet': None}

    finally:
        if code:
            lock(_id, code)


def lock(_id, code):
    try:
        payload = {
            "edit_code": code,
            "flock": "Lock"
        }

        data = httptools.downloadpage('%s/%s/lock' % (FP_URL, _id), payload).data

        if scrapertools.find_single_match(data, '<li class="lock" title="Lock edit">'):
            data = httptools.downloadpage('%s/%s/lock' % (FP_URL, _id), payload).data

        e = re.findall('class="errors"([^:]+)', data)
        if re.findall('<li class="lock" title="Lock edit">', data) or (e and 'WANING' not in e[0]):
            raise Exception()

        return True
    except Exception:
        return False


def unlock(_id, code):
    try:
        payload = {
            "edit_code": code,
            "funlock": "Unlock"
        }

        data = httptools.downloadpage('%s/%s/unlock' % (FP_URL, _id), payload).data

        if scrapertools.find_single_match(data, '<li class="lock" title="Unlock edit">'):
            data = httptools.downloadpage('%s/%s/unlock' % (FP_URL, _id), payload).data

        e = re.findall('class="errors"([^:]+)', data)
        if re.findall('<li class="lock" title="Unlock edit">', data) or (e and 'WANING' not in e[0]):
            raise Exception()

        return True
    except Exception:
        return False
