# -*- coding: utf-8 -*-

from core.libs import *
import os
import socket
from smb.SMBConnection import SMBConnection
from nmb.NetBIOS import NetBIOS
import six

_remote = None


def parse_url(url):
    # logger.debug("Url: %s" % url)
    url = url.strip()
    import re
    patron = "^smb://(?:([^;\n]+);)?(?:([^:@\n]+)[:|@])?(?:([^@\n]+)@)?([^/]+)/([^/\n]+)([/]?.*?)$"
    domain, user, password, server_name, share_name, path = re.compile(patron, re.DOTALL).match(url).groups()

    server_name, server_ip = get_server_name_ip(server_name)

    if not user:
        user = 'guest'
    if not password:
        password = ""
    if not domain:
        domain = ""
    if path.endswith("/"):
        path = path[:-1]
    if not path:
        path = "/"

    # logger.debug("Dominio: '%s' |Usuario: '%s' | Password: '%s' | Servidor: '%s' | IP: '%s' | Share Name: '%s' | Path:
    # '%s'" % (domain, user, password, server_name, server_ip, share_name, path))
    return server_name, server_ip, share_name, six.ensure_text(path), user, password, domain


def get_server_name_ip(server):
    import re
    if re.compile(r"^\d+.\d+.\d+.\d+$").findall(server):
        server_ip = server
        server_name = None
    else:
        server_ip = None
        server_name = server.upper()

    if not server_ip:
        server_ip = NetBIOS().queryName(server_name)[-1]

    if not server_ip:
        server_ip = socket.gethostbyname(server)

    if not server_name:
        server_name = NetBIOS().queryIPForName(server_ip)[-1]

    return server_name, server_ip


def connect(url):
    # logger.debug("Url: %s" % url)
    global _remote
    server_name, server_ip, share_name, path, user, password, domain = parse_url(url)
    if not _remote or not _remote.sock or not server_name == _remote.remote_name:
        _remote = SMBConnection(user, password, domain, server_name)
        _remote.connect(server_ip, 139)

    return _remote, share_name, path


def listdir(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        files = [six.ensure_str(f.filename) for f in remote.listPath(share_name, path) if f.filename not in [".", ".."]]
        return files
    except Exception as e:
        raise type(e)(e.args[0], "")


def walk(url, topdown=True, onerror=None):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)

    try:
        names = remote.listPath(share_name, path)
    except Exception as _err:
        if onerror is not None:
            onerror(_err)
        return

    dirs, nondirs = [], []
    for name in names:
        if name.filename in [".", ".."]:
            continue
        if name.isDirectory:
            dirs.append(six.ensure_str(name.filename))
        else:
            nondirs.append(six.ensure_str(name.filename))
    if topdown:
        yield url, dirs, nondirs

    for name in dirs:
        new_path = "/".join(url.split("/") + [name])
        for x in walk(new_path, topdown, onerror):
            yield x
    if not topdown:
        yield url, dirs, nondirs


def get_attributes(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        return remote.getAttributes(share_name, path)
    except Exception as e:
        raise type(e)(e.args[0], "")


def mkdir(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        remote.createDirectory(share_name, path)
    except Exception as e:
        raise type(e)(e.args[0], "")


def makedirs(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        pos = '/'
        for p in path.split('/')[1:]:
            if p not in [f.filename for f in remote.listPath(share_name, pos) if f.isDirectory]:
                remote.createDirectory(share_name, pos + p + '/')
            pos += p + '/'
    except Exception as e:
        raise type(e)(e.args[0], "")


def smb_open(url, mode):
    # logger.debug("Url: %s" % url)
    return SMBFile(url, mode)


def isfile(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        files = [f.filename for f in remote.listPath(share_name, os.path.dirname(path)) if not f.isDirectory]
    except Exception as e:
        raise type(e)(e.args[0], "")
    return os.path.basename(path) in files


def isdir(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        folders = [f.filename for f in remote.listPath(share_name, os.path.dirname(path)) if f.isDirectory]
    except Exception as e:
        raise type(e)(e.args[0], "")
    return os.path.basename(path) in folders or path == "/"


def exists(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        files = [f.filename for f in remote.listPath(share_name, os.path.dirname(path))]
    except Exception as e:
        raise type(e)(e.args[0], "")
    return os.path.basename(path) in files or path == "/"


def remove(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        remote.deleteFiles(share_name, path)
    except Exception as e:
        raise type(e)(e.args[0], "")


def rmdir(url):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    try:
        remote.deleteDirectory(share_name, path)
    except Exception as e:
        raise type(e)(e.args[0], "")


def rename(url, new_name):
    # logger.debug("Url: %s" % url)
    remote, share_name, path = connect(url)
    _, _, _, new_name, _, _, _ = parse_url(new_name)
    try:
        remote.rename(share_name, path, new_name)
    except Exception as e:
        raise type(e)(e.args[0], "")


class SMBFile(object):
    def __init__(self, url, mode="r"):
        import random
        try:
            import xbmc
        except ImportError:
            xbmc = None
        self.url = url
        self.remote, self.share, self.path = connect(url)
        self.mode = mode
        self.binary = False
        self.canread = False
        self.canwrite = False
        self.closed = True
        self.size = 0
        self.pos = 0
        if xbmc:
            self.tmp_path = os.path.join(xbmc.translatePath("special://temp/"), "%08x" % (random.getrandbits(32)))
        else:
            self.tmp_path = os.path.join(os.getenv("TEMP") or os.getenv("TMP") or os.getenv("TMPDIR"),
                                         "%08x" % (random.getrandbits(32)))
        self.tmp_file = None

        self.__get_mode__()

    def __del__(self):
        if self.tmp_file:
            self.tmp_file.close()

        if os.path.isfile(self.tmp_path):
            os.remove(self.tmp_path)

    def tmpfile(self):
        if self.tmp_file:
            self.tmp_file.close()

        self.tmp_file = open(self.tmp_path, "w+b")
        return self.tmp_file

    def __get_mode__(self):
        if "r+" in self.mode:
            try:
                attr = self.remote.getAttributes(self.share, self.path)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.size = attr.file_size
            self.canread = True
            self.canwrite = True
            self.closed = False

        elif "r" in self.mode:
            try:
                attr = self.remote.getAttributes(self.share, self.path)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.size = attr.file_size
            self.canread = True
            self.closed = False

        elif "w+" in self.mode:
            try:
                self.remote.storeFileFromOffset(self.share, self.path, self.tmpfile(), 0, truncate=True)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.canread = True
            self.canwrite = True
            self.closed = False

        elif "w" in self.mode:
            try:
                self.remote.storeFileFromOffset(self.share, self.path, self.tmpfile(), 0, truncate=True)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.canwrite = True
            self.closed = False

        elif "a+" in self.mode:
            try:
                self.remote.storeFileFromOffset(self.share, self.path, self.tmpfile(), 0)
                attr = self.remote.getAttributes(self.share, self.path)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.size = attr.file_size
            self.pos = self.size
            self.canwrite = True
            self.canread = True
            self.closed = False

        elif "a" in self.mode:
            try:
                self.remote.storeFileFromOffset(self.share, self.path, self.tmpfile(), 0)
                attr = self.remote.getAttributes(self.share, self.path)
            except Exception as e:
                raise type(e)(e.args[0], "")

            self.size = attr.file_size
            self.pos = self.size
            self.canwrite = True
            self.closed = False

        if "b" in self.mode:
            self.binary = True

    def seek(self, offset, whence=0):
        if whence == 0:
            self.pos = offset
        if whence == 1:
            self.pos += offset
        if whence == 2:
            self.pos = self.size + offset

        if self.pos < 0:
            self.pos = 0

    def tell(self):
        return self.pos

    def write(self, data):
        if not self.canwrite:
            raise IOError("File not open for writing")
        f = self.tmpfile()
        f.write(data)
        f.seek(0)
        self.remote.storeFileFromOffset(self.share, self.path, f, self.pos)
        self.pos += len(data)
        if self.pos > self.size:
            self.size = self.pos

    def read(self, size=-1):
        if not self.canread:
            raise IOError("File not open for reading")
        f = self.tmpfile()
        self.remote.retrieveFileFromOffset(self.share, self.path, f, self.pos, size)
        f.seek(0)
        data = f.read()
        self.seek(len(data), 1)
        if self.binary:
            return data
        else:
            return u''.join([six.unichr(x) for x in bytearray(data)])

    def truncate(self, size=None):
        if not self.canwrite:
            raise IOError("File not open for writing")
        data = self.read(size)
        f = self.tmpfile()
        self.pos = 0
        f.write(data)
        f.seek(0)
        self.remote.storeFileFromOffset(self.share, self.path, f, self.pos, truncate=True)

    def close(self):
        self.remote.close()
        self.closed = True
        self.canwrite = False
        self.canread = False

    def flush(self):
        pass

    def writelines(self, sequence):
        for line in sequence:
            self.write(line)

    def readlines(self, sizehint=0):
        if not self.canread:
            raise IOError("File not open for reading")
        f = self.tmpfile()
        self.remote.retrieveFileFromOffset(self.share, self.path, f, self.pos)
        f.seek(0)
        data = f.readlines(sizehint)
        self.pos += len(data)

        if not self.binary:
            data = [l.replace("\r", "") for l in data]
        return data

    def readline(self, size=-1):
        if not self.canread:
            raise IOError("File not open for reading")
        f = self.tmpfile()
        self.remote.retrieveFileFromOffset(self.share, self.path, f, self.pos, size)
        f.seek(0)
        data = f.readline(size)
        self.pos += len(data)

        if not self.binary:
            data = data.replace("\r", "")
        return data

    def __iter__(self):
        return self.readlines().__iter__()

    def xreadlines(self):
        return self.__iter__()

    def __repr__(self):
        return self.__str__()

    def __str__(self):
        return "<open SMBFile '%s', mode '%s' at %s>" % (self.url, self.mode, hex(id(self)))

    @property
    def __class__(self):
        return "<type 'file'>"
