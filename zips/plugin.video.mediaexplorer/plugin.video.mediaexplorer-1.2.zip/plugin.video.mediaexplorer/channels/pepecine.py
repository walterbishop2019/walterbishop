# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://verencasa.com'

LNG = Languages({
    Languages.es: ['castellano', 'zc'],
    Languages.en: ['ingles', 'zi'],
    Languages.la: ['latino', 'zl'],
    Languages.vo: ['vo'],
    Languages.sub_es: ['subtitulado', 'zs'],
})

QLT = Qualities({
    Qualities.rip: ['hd rip', 'rip', 'dvd rip'],
    Qualities.hd: ['hd 720', 'hd-tv'],
    Qualities.hd_full: ['hdfull', 'hd 1080'],
    Qualities.scr: ['ts-scr', 'cam']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Novedades',
        action='ultimos_enlaces',
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Populares',
        action='content',
        url= HOST + '/secure/titles?type=movie&order=popularity:desc&onlyStreamable=true&page=%s',
        page=1,
        content_type='movies',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Generos',
        action='generos',
        content_type='items',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        content_type='movies',
        query=True,
        type='search',
        group=True
    ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Últimos Episodios',
        action='ultimos_enlaces',
        #action='content',
        content_type='episodes',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Nuevas Series',
        action='newest_tvshow',
        content_type='tvshows',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Populares',
        action='content',
        url=HOST + '/secure/titles?type=series&order=popularity:desc&onlyStreamable=true&page=%s',
        page=1,
        content_type='tvshows',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Generos',
        action='generos',
        content_type='items',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        content_type='tvshows',
        query=True,
        type='search',
        group=True
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    if item.content_type == 'movies':
        url = HOST + '/secure/titles?type=movie&order=popularity:desc&onlyStreamable=true&page=%s'
    else:
        url = HOST + '/secure/titles?type=series&order=popularity:desc&onlyStreamable=true&page=%s'


    generos = ['Accion', 'Animacion', 'Aventura', 'CienciaFiccion', 'Comedia', 'Crimen',
               'Drama', 'Fantasia', 'Guerra', 'Misterio', 'Musica', 'Romance', 'Suspense', 'Terror', 'Western']

    for g in generos:
        itemlist.append(item.clone(
            label=g,
            action='content',
            url = url + '&genre=' + g,
            page=1
        ))

    return itemlist


def ultimos_enlaces(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        if item.content_type == 'movies':
            item.url = HOST + '/last/estrenos-peliculas-online.php'
        else:
            item.url = HOST + '/last/estrenos-episodios-online.php'

    data = httptools.downloadpage(item.url).data
    patron = '''<div class='online'><table><tr><td><a href=([^\s]+) target="_parent"><img src=([^\s]+) class="s8" alt="([^"]+).*?<div class="s7"> \d+-([^\s]+)'''

    incluidas = list()
    for url, poster, titulo, lang in scrapertools.find_multiple_matches(data, patron):
        if lang.startswith('z'):
            continue

        if item.content_type == 'movies':
            id = scrapertools.find_single_match(url, '/([^/]+)$')
            url_title = '{0}/secure/titles/{1}?titleId={1}'.format(HOST, id)
            type = 'movie'
        else:
            id, season, episode = scrapertools.find_single_match(url,'/titles/([^/]+)/season/(\d+)/episode/(\d+)')
            url_title = '{0}/secure/titles/{1}?titleId={1}&seasonNumber={2}&episodeNumber={3}'.format(HOST, id, season, episode)
            type = 'episode'

        if url in incluidas:
            for i in itemlist:
                lng = LNG.get(lang.lower())
                if i.url == url_title and lng not in i.lang:
                    l = i.lang
                    l.append(lng)
                    i.lang = l
                    break
            continue

        new_item = item.clone(
            poster=poster,
            url=url_title,
            type=type,
            content_type='servers',
            action='findvideos',
            title=titulo.decode('iso-8859-1').encode('utf8'),
            lang=[LNG.get(lang.lower())]
        )

        if item.content_type != 'movies':
            new_item.title = new_item.title.replace('%sx%s' %(season, episode), '').strip()
            new_item.tvshowtitle = new_item.title
            new_item.season = int(season)
            new_item.episode = int (episode)


        itemlist.append(new_item)
        incluidas.append(url)

    # Paginacion
    if itemlist:
        if not item.page:
            item.page = 0

        if item.page < 10:
            itemlist = itemlist[item.page * 30 : item.page * 30 + 29]
            itemlist.append(item.clone(page = item.page + 1, type='next', url=item.url))

    return itemlist


def search(item):
    logger.trace()
    item.url = '%s/secure/search/%s' % (HOST, item.query.replace(" ", "%20"))
    return content(item)


def newest_tvshow(item):
    logger.trace()
    item.url = HOST + '/secure/titles?type=series&order=release_date:desc&onlyStreamable=true&page=%s'
    item.page = 1
    return content(item)


def content(item):
    logger.trace()
    itemlist = list()

    if item.query:
        data = httptools.downloadpage(item.url).data
        data = jsontools.load_json(data).get('results',{})
        pagination = None
    else:
        data = httptools.downloadpage(item.url % item.page).data
        pagination = jsontools.load_json(data).get('pagination',{})
        data= pagination.get('data',{})

    if data:
        for e in data:
            if e['type'] != 'title': continue

            new_item =item.clone(
                title=e['name'].strip(),
                poster=e.get('poster', item.poster),
                plot=e.get('description', ''),
                year=e.get('year',None),
                url='{0}/secure/titles/{1}?titleId={1}'.format(HOST, e['id']),
                trailer= e.get('trailer', None)
            )

            if item.content_type == 'movies' and not e.get('is_series', True):
                new_item.type = 'movie'
                new_item.content_type = 'servers'
                new_item.action = 'findvideos'
                itemlist.append(new_item)

            elif item.content_type != 'movies' and e.get('is_series', False):
                new_item.type = 'tvshow'
                new_item.content_type = 'seasons'
                new_item.action = 'seasons'
                itemlist.append(new_item)

        # paginacion
        if pagination and (pagination['current_page'] < pagination['last_page']):
            itemlist.append(item.clone(page=item.page + 1, type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = jsontools.load_json(data).get('title', {}).get('seasons', {})

    for s in data:
        itemlist.append(item.clone(
            action="episodes",
            url =  item.url + '&seasonNumber=%s' % s['number'],
            season=int(s['number']),
            type='season',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = jsontools.load_json(data).get('title', {}).get('season', {}).get('episodes',{})

    for e in data:
        itemlist.append(item.clone(
            title=e['name'].strip(),
            url= item.url + '&episodeNumber=%s' % e['episode_number'],
            action="findvideos",
            episode=e['episode_number'],
            season=e['season_number'],
            type='episode',
            plot=e['description'],
            thumb=e['poster'],
            content_type='servers'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    videos = jsontools.load_json(data).get('title',{}).get('videos',[])

    if not videos:
        try:
            videos = jsontools.load_json(data).get('title', {}).get('season', {}).get('episodes', [])
            videos = videos[item.episode - 1].get('videos',[])
        except:
            pass

    for v in videos:
        if v['quality']:
            lng = scrapertools.find_single_match(v['name'], '\d+-([^\s]+)').lower()
            itemlist.append(item.clone(
                url=v['url'],
                type='server',
                action='play',
                lang=LNG.get(lng),
                quality=QLT.get(v['quality'].lower()),
                stream= False if lng.startswith('z') else True
            ))

    return servertools.get_servers_itemlist(itemlist)
