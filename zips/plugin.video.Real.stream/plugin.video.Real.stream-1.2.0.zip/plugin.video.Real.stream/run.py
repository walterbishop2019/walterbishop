# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.1.9
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'videos' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'activar' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'favcopy' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'anticopia' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
i1i = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'fav' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iIiIIIi = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
ooo00OOOooO = 'bienvenida'
O00OOOoOoo0O = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooOOO00Ooo = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if ooOOO00Ooo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
IiIIIi1iIi = 'LnR4dA==' . decode ( 'base64' )
if 68 - 68: i11iIiiIii % o00O0oo + i11iIiiIii
if 31 - 31: II111iiii . OOooOOo
if 1 - 1: ii11ii1ii / o0000oOoOoO0o % O0ooOooooO * i1I111II1I . i11iIiiIii
III1Iiii1I11 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
IIIIiiIiI = iIiIIIi + ooo00OOOooO + IiIIIi1iIi
o00oooO0Oo = 'http://www.youtube.com'
o0O0OOO0Ooo = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iiIiI = 'http://bit.ly/2ImelUx'
I1 = '.xsl.pt'
OOO00O0O = 'L21hc3Rlci8=' . decode ( 'base64' )
iii = o0O0OOO0Ooo + I1
oOooOOOoOo = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
i1Iii1i1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 91 - 91: o00O0oo + OOooOOo . IIII * o00O0oo + OOooOOo * ii11ii1ii
O000OOOOOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
Iiii1i1 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oo000o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiIi1IIi1I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o0OoOO000ooO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0o0o0oO0oOO = '#(.+?),(.+)\s*(.+)'
ii1Ii11I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 80 - 80: II111iiii
O0Oi1I1I = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiI1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
IiIiiIIiI = '[\'"](.*?)[\'"]'
ooOO0OOOO0oo0 = r'066">\s*(.+)</f'
I11iiI1i1 = '[\'"](.*?)[\'"]'
I1i1Iiiii = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
OOo0oO00ooO00 = '[\'"](.*?)[\'"]'
oOO0O00oO0Ooo = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
oO0Oo0O0o = 'https://pastebin.com/raw/SP9JQdLR'
OOI1iI1ii1II = '[\'"](.*?)[\'"]'
O0O0OOOOoo = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
oOooO0 = O0O0OOOOoo + I11i
Ii1I1Ii = '[\'"](.*?)[\'"]'
OOoO0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00O0
ii1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1iIIiiIIi1i = '0110R0N' . replace ( '0110R0N' , 'R0N' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oOOo0O00o
OOO = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iiiiI = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
OOoO = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '01109DI' . replace ( '01109DI' , '9DI' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01103hs' . replace ( '01103hs' , '3hs' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01107DW' . replace ( '01107DW' , '7DW' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + Oo0O00O000
oo = '0110mLl' . replace ( '0110mLl' , 'mLl' )
I1111i = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + oo
iIIii = '01102Hj' . replace ( '01102Hj' , '2Hj' )
o00O0O = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oooO = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110x64' . replace ( '0110x64' , 'x64' )
ooo = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110vUE' . replace ( '0110vUE' , 'vUE' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01106cf' . replace ( '01106cf' , '6cf' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + OOo0
oo0o = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1i111I = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110MHY' . replace ( '0110MHY' , 'MHY' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
O0o0oO = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
I11iiiiI1i = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iI1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '0110pzp' . replace ( '0110pzp' , 'pzp' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = '01105yt' . replace ( '01105yt' , '5yt' )
OOo0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + ii1I1i11
if 68 - 68: oO0o0ooO0 . O0oO % OoooooooOO . O0oO
if 64 - 64: iIii1I11I1II1 / OOooOOo . II111iiii + OoooooooOO . OoOO
oOIIiIi = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OOoOooOoOOOoo = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + oOIIiIi
Iiii1iI1i = '1001Hky' . replace ( '1001Hky' , 'Hky' )
I1ii1ii11i1I = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + Iiii1iI1i
o0OoOO = '1001VFU' . replace ( '1001VFU' , 'VFU' )
O0O0Oo00 = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + o0OoOO
oOoO00o = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oO00O0 = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oOoO00o
IIi1IIIi = '4224tZO' . replace ( '4224tZO' , 'tZO' )
O00Ooo = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + IIi1IIIi
if 52 - 52: o00O0oo - ii11ii1ii + o00O0oo % o0000oOoOoO0o
if 35 - 35: iIii1I11I1II1
if 42 - 42: Oooo0Ooo000 . OOooOOo . i1IIi + OoOO0ooOOoo0O + IIII + OOooOOo
if 31 - 31: O0ooOooooO . IIII - iI . OoooooooOO / OoooooooOO
if 56 - 56: OoOO / oO0o0ooO0 / i11iIiiIii + OoooooooOO - ii11ii1ii - O0oO
if 21 - 21: O0 % i1I111II1I . OOooOOo / II111iiii + i1I111II1I
def OOOO0O00o ( ) :
 if 62 - 62: iIii1I11I1II1
 if 12 - 12: IIII / o0000oOoOoO0o
 try :
  iiI1I1 = ooO ( O0O0ooOOO )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   try :
    if 77 - 77: o0000oOoOoO0o / OoooooooOO
    iIiIi11 = OO0O0Ooo
    if 46 - 46: o0000oOoOoO0o % iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
    Oo00o0OO0O00o = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    Oo00o0OO0O00o . doModal ( )
    if ( Oo00o0OO0O00o . isConfirmed ( ) ) :
     O0Oooo = xbmcgui . DialogProgress ( )
     O0Oooo . create ( 'Realstream:' , 'Buscando ...' )
     iiIi1i = range ( 0 , 76 )
     for I1i11111i1i11 in iiIi1i :
      I1i11111i1i11 = I1i11111i1i11 + 1
      if 77 - 77: o00O0oo + OoOO / oO0o0ooO0 + O0 * o0000oOoOoO0o
     I1ii11 = urllib . quote_plus ( Oo00o0OO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     oOoOoOoo0 = ooO ( iIiIi11 )
     ii = re . compile ( O000OOOOOo ) . findall ( oOoOoOoo0 )
     for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
      if 78 - 78: iI . o0000oOoOoO0o . IIII . O0oO + oO0o0ooO0
      O0Oooo . update ( I1i11111i1i11 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % Ii1i1iI )
      xbmc . sleep ( 1 )
      if O0Oooo . iscanceled ( ) : break ;
      if re . search ( I1ii11 , i1ii1II1ii ( Ii1i1iI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 28 - 28: o00O0oo
       O0Oooo . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       O0Oooo . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       O0Oooo . close ( )
       O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
       if 96 - 96: OoOO0ooOOoo0O . o0000oOoOoO0o - iI
       if 99 - 99: i1I111II1I . ii11ii1ii - o0oO0 % o0oO0 * O0 . II111iiii
     iIIII1iIIii ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + I1ii11 + "[/COLOR] ,2000)" )
     if 52 - 52: o0000oOoOoO0o % ii11ii1ii
   except : iIIII1iIIii ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 64 - 64: O0 % O0oO % O0 * OoOO . oO0o0ooO0 + OOooOOo
 except :
  pass
  if 75 - 75: O0oO . OoooooooOO % o0000oOoOoO0o * O0oO % OoooooooOO
def I11i1iIiIIIIIii ( ) :
 if 58 - 58: o0000oOoOoO0o / i1I111II1I . OoOO0ooOOoo0O / OoooooooOO + Oooo0Ooo000
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 86 - 86: O0oO * OOooOOo + O0oO + II111iiii
 if O0ii1ii1ii == 'true' :
  if 8 - 8: Oooo0Ooo000 - O0ooOooooO / iI
  try :
   iiI1I1 = ooO ( IIIIiiIiI )
   ii = re . compile ( oOooOOOoOo ) . findall ( iiI1I1 )
   for oo0oOoo , oOOO0o00o in ii :
    try :
     if 1 - 1: OOooOOo / i1I111II1I * iI
     if 1 - 1: O0oO * o0000oOoOoO0o . OoOO0ooOOoo0O / O0
     O00 = oo0oOoo
     O0ooo0 = oOOO0o00o
     if 8 - 8: iI + II111iiii / O0ooOooooO / O0oO
     if 74 - 74: O0 / i1IIi
     from datetime import datetime
     if 78 - 78: OoooooooOO . OoOO + iI - i1IIi
     ii1O0 = datetime . now ( )
     iII1 = ii1O0 . strftime ( '%d/%m/%Y' )
     if 27 - 27: OoOO . O0oO + OoOO0ooOOoo0O / iIii1I11I1II1 % O0ooOooooO . iI
     IIIIi1 = ooO ( I11iiiiI1i )
     ii = re . compile ( ooOO0OOOO0oo0 ) . findall ( IIIIi1 )
     for iIi11iiIiI1I in ii :
      if 3 - 3: i1IIi / II111iiii / i11iIiiIii * i1IIi - II111iiii
      Ii = "[B]" + O00 + "[/B]"
      iII1111III1I = "" + O0ooo0 + ""
      ii11i = "[COLOR white]Hoy: " + iII1 + ", Es usted el visitante numero: [B][COLOR gold]" + iIi11iiIiI1I + "[/B][/COLOR]"
      if 100 - 100: iI % iIii1I11I1II1 * II111iiii - O0ooOooooO
      xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ii , iII1111III1I , ii11i )
    except :
     pass
     if 92 - 92: iI
  except :
   pass
   if 22 - 22: ii11ii1ii % O0ooOooooO * o00O0oo / IIII % i11iIiiIii * O0oO
  try :
   oOoOoOoo0 = ooO ( IIIIiIiIi1 )
   ii = re . compile ( IiIiiIIiI ) . findall ( oOoOoOoo0 )
   for Oo00OoOo in ii :
    if 24 - 24: i11iIiiIii - Oooo0Ooo000
    import xbmc
    import xbmcaddon
    if 21 - 21: O0oO
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 92 - 92: i11iIiiIii / Oooo0Ooo000 - O0ooOooooO % iI * Oooo0Ooo000 + ii11ii1ii
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    ii1Oo0000oOo = Oo00OoOo
    if 31 - 31: O0oO . Oooo0Ooo000 * iI + i11iIiiIii * oO0o0ooO0
    Ii = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + Oo00OoOo + " [/B][/COLOR]"
    OO0ooo0o0O0Oooooo = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , Ii , OO0ooo0o0O0Oooooo , __icon__ ) )
    if 1 - 1: iI % OoOO0ooOOoo0O * ii11ii1ii
    if iIiiiI1IiI1I1 < Oo00OoOo :
     if 55 - 55: OoOO0ooOOoo0O
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % Oo00OoOo )
     if 87 - 87: OoooooooOO % O0ooOooooO . OOooOOo / iI
     if 8 - 8: O0oO + o0000oOoOoO0o
  except :
   pass
   if 90 - 90: o00O0oo
   if 62 - 62: Oooo0Ooo000 . i1I111II1I . OoooooooOO
   if 11 - 11: IIII / O0oO
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 73 - 73: i1IIi / i11iIiiIii
    if 58 - 58: ii11ii1ii . II111iiii + oO0o0ooO0 - i11iIiiIii / II111iiii / O0
    if 85 - 85: OoOO0ooOOoo0O + IIII
def i1ii1II1ii ( s ) :
 if 10 - 10: i1I111II1I / OoOO + OoOO0ooOOoo0O / i1IIi
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 27 - 27: o0oO0
def oO0OO0 ( file ) :
 if 82 - 82: i1I111II1I - i1I111II1I + OoOO0ooOOoo0O
 try :
  II111Ii1i1 = open ( file , 'r' )
  iiI1I1 = II111Ii1i1 . read ( )
  II111Ii1i1 . close ( )
  return iiI1I1
 except :
  pass
  if 98 - 98: OoOO . OoOO * oO0o0ooO0 * II111iiii * Oooo0Ooo000
def ooO ( url ) :
 if 92 - 92: ii11ii1ii
 try :
  iI11I = urllib2 . Request ( url )
  iI11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  ooO000 = urllib2 . urlopen ( iI11I )
  oOOOO = ooO000 . read ( )
  ooO000 . close ( )
  return oOOOO
 except urllib2 . URLError , IiIi1ii111i1 :
  print 'We failed to open "%s".' % url
  if hasattr ( IiIi1ii111i1 , 'code' ) :
   print 'We failed with error code - %s.' % IiIi1ii111i1 . code
  if hasattr ( IiIi1ii111i1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , IiIi1ii111i1 . reason
   if 31 - 31: IIII + O0
def oO0oOOoo00000 ( url ) :
 iI11I = urllib2 . Request ( url )
 iI11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 iI11I . add_header ( 'Referer' , '%s' % url )
 iI11I . add_header ( 'Connection' , 'keep-alive' )
 ooO000 = urllib2 . urlopen ( iI11I )
 oOOOO = ooO000 . read ( )
 ooO000 . close ( )
 return oOOOO
 if 52 - 52: OOooOOo
 if 51 - 51: i1I111II1I
def o00o ( ) :
 if 46 - 46: II111iiii % o0000oOoOoO0o % iIii1I11I1II1 - ii11ii1ii . OoooooooOO - i1I111II1I
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 59 - 59: i1I111II1I . IIII % II111iiii
 if OOO00O == 'true' :
  if 39 - 39: o00O0oo
  iIIII1iIIii ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  iIIII1iIIii ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , I1IIIii , oo00 )
  iIIII1iIIii ( '[COLOR %s]Peliculas[/COLOR] ' % oo00O00oO , 'movieDB' , 116 , I1I , oo00 )
  iIIII1iIIii ( '[COLOR %s]Series[/COLOR] ' % oo00O00oO , 'movieDB' , 117 , iIi11Ii1 , oo00 )
  if 97 - 97: IIII - OoOO / o0oO0 . i11iIiiIii % oO0o0ooO0 * oO0o0ooO0
  if 1 - 1: OOooOOo % iI
 if oooooOoo0ooo == 'true' :
  iIIII1iIIii ( '[COLOR %s]Ajustes[/COLOR]' % oo00O00oO , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 65 - 65: OOooOOo + OoOO0ooOOoo0O / IIII
  if 83 - 83: o0000oOoOoO0o . O0ooOooooO - ii11ii1ii
  if iIIIi1 == 'true' :
   Ooo0O ( )
   if 87 - 87: i1I111II1I % II111iiii
  if I1I1IiI1 == 'true' :
   I11II11I1iII ( )
   Ii1iI111 ( )
   if 51 - 51: i1I111II1I * O0 / II111iiii . o0oO0 % IIII / OOooOOo
  if O0o0O00Oo0o0 == 'false' :
   if 9 - 9: OOooOOo % OOooOOo % II111iiii
   Ii = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   iII1111III1I = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   ii11i = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 30 - 30: i1I111II1I + Oooo0Ooo000 - i1I111II1I . i1I111II1I - II111iiii + O0
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ii , iII1111III1I , ii11i )
   if 86 - 86: i1IIi
def IIi11IIiIii1 ( ) :
 iIIII1iIIii ( '[COLOR orange]Buscador por id[/COLOR]' , o00oooO0Oo , 127 , oOOoo00O0O , oo00 )
 if 17 - 17: o0oO0 + oO0o0ooO0 . OoOO - ii11ii1ii * i11iIiiIii
def iioOo0OoOOo0 ( ) :
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iIIII1iIIii ( '[COLOR %s]The movie DB[/COLOR]' % oo00O00oO , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 30 - 30: o00O0oo % OOooOOo
 iIIII1iIIii ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
 if 89 - 89: Oooo0Ooo000 + OoooooooOO + Oooo0Ooo000 * i1IIi + iIii1I11I1II1 % O0oO
 if 59 - 59: IIII + i11iIiiIii
 if 88 - 88: i11iIiiIii - iI
def O0iIi1IiII ( ) :
 if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
 o00o ( )
 iioOo0OoOOo0 ( )
 if 20 - 20: o0000oOoOoO0o / i1IIi
def oOIi111 ( ) :
 if 67 - 67: O0
 O0iIi1IiII ( )
 if 52 - 52: II111iiii . iI / OoOO0ooOOoo0O / OoooooooOO . i11iIiiIii
def I1i1i ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OOOOooO0oO00O0o ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 70 - 70: Oooo0Ooo000
 if 16 - 16: O0ooOooooO - OoooooooOO % ii11ii1ii
def i11i1iIiii ( ) :
 urlresolver . display_settings ( )
 if 71 - 71: o00O0oo % iI - OOooOOo % O0oO - O0
def I11II11I1iII ( ) :
 iIIII1iIIii ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oo00O00oO , 'resolve' , 120 , O0o0 , oo00 )
 if 67 - 67: IIII + ii11ii1ii
def OoOo000oOo0oo ( ) :
 if 65 - 65: OoOO0ooOOoo0O / OoOO % i1I111II1I
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 45 - 45: OoOO0ooOOoo0O
def Ii1iI111 ( ) :
 iIIII1iIIii ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oo00O00oO , 'resolve' , 140 , O0o0 , oo00 )
 if 66 - 66: OoOO
def Ooo0O ( ) :
 if 56 - 56: O0
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iIIII1iIIii ( '[COLOR %s]Buscador[/COLOR]' % oo00O00oO , 'search' , 111 , o0oOoO00o , oo00 )
 iIIII1iIIii ( '[COLOR %s]Estrenos[/COLOR]' % oo00O00oO , o00oooO0Oo , 3 , i11 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 26 , I11 , oo00 )
 iIIII1iIIii ( '[COLOR %s]4K[/COLOR]' % oo00O00oO , o00oooO0Oo , 141 , O0o0Oo , oo00 )
 iIIII1iIIii ( '[COLOR %s]Novedades[/COLOR]' % oo00O00oO , o00oooO0Oo , 2 , i1111 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Accion[/COLOR]' % oo00O00oO , o00oooO0Oo , 5 , Oo0o0000o0o0 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Animacion[/COLOR]' % oo00O00oO , o00oooO0Oo , 6 , oOo0oooo00o , oo00 )
 iIIII1iIIii ( '[COLOR %s]Artes Marciales[/COLOR]' % oo00O00oO , o00oooO0Oo , 29 , o0 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Aventuras[/COLOR]' % oo00O00oO , o00oooO0Oo , 7 , oO0o0o0ooO0oO , oo00 )
 iIIII1iIIii ( '[COLOR %s]Belico[/COLOR]' % oo00O00oO , o00oooO0Oo , 8 , oo0o0O00 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oo00O00oO , o00oooO0Oo , 9 , oO , oo00 )
 iIIII1iIIii ( '[COLOR %s]Cine Clasico[/COLOR]' % oo00O00oO , o00oooO0Oo , 30 , i1iiIIiiI111 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Comedia[/COLOR]' % oo00O00oO , o00oooO0Oo , 10 , oooOOOOO , oo00 )
 iIIII1iIIii ( '[COLOR %s]Crimen[/COLOR]' % oo00O00oO , o00oooO0Oo , 11 , i1iiIII111ii , oo00 )
 iIIII1iIIii ( '[COLOR %s]Drama[/COLOR]' % oo00O00oO , o00oooO0Oo , 12 , i1iIIi1 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Familiar[/COLOR]' % oo00O00oO , o00oooO0Oo , 13 , ii11iIi1I , oo00 )
 iIIII1iIIii ( '[COLOR %s]Fantasia[/COLOR]' % oo00O00oO , o00oooO0Oo , 14 , iI111I11I1I1 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Historia[/COLOR]' % oo00O00oO , o00oooO0Oo , 15 , OOooO0OOoo , oo00 )
 iIIII1iIIii ( '[COLOR %s]Misterio[/COLOR]' % oo00O00oO , o00oooO0Oo , 16 , oOOoO0 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Musical[/COLOR]' % oo00O00oO , o00oooO0Oo , 17 , O0OoO000O0OO , oo00 )
 iIIII1iIIii ( '[COLOR %s]Romance[/COLOR]' % oo00O00oO , o00oooO0Oo , 18 , iiI1IiI , oo00 )
 iIIII1iIIii ( '[COLOR %s]Thriller[/COLOR]' % oo00O00oO , o00oooO0Oo , 19 , II11iiii1Ii , oo00 )
 iIIII1iIIii ( '[COLOR %s]Suspense[/COLOR]' % oo00O00oO , o00oooO0Oo , 20 , ooOoOoo0O , oo00 )
 iIIII1iIIii ( '[COLOR %s]Terror[/COLOR]' % oo00O00oO , o00oooO0Oo , 21 , OooO0 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Western[/COLOR]' % oo00O00oO , o00oooO0Oo , 22 , OO0o , oo00 )
 iIIII1iIIii ( '[COLOR %s]Spain[/COLOR]' % oo00O00oO , o00oooO0Oo , 23 , II , oo00 )
 iIIII1iIIii ( '[COLOR %s]Super heroes[/COLOR]' % oo00O00oO , o00oooO0Oo , 24 , iIii1 , oo00 )
 iIIII1iIIii ( '[COLOR %s]Sagas[/COLOR]' % oo00O00oO , o00oooO0Oo , 25 , Ooo , oo00 )
 if 61 - 61: o0000oOoOoO0o / IIII / ii11ii1ii * O0
def iIII1i1i ( ) :
 if 35 - 35: II111iiii * O0oO - OoooooooOO . O0oO . O0oO
 iIIII1iIIii ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
 if 11 - 11: Oooo0Ooo000 / OoOO0ooOOoo0O + O0oO % iIii1I11I1II1
 II1II1iIIi11 ( )
 if 49 - 49: OoooooooOO * O0oO - ii11ii1ii . oO0o0ooO0
 iIIII1iIIii ( '[COLOR %s]En emision[/COLOR]' % oo00O00oO , o00oooO0Oo , 150 , I11II1i , oo00 )
 iIIII1iIIii ( '[COLOR %s]Mejor valoradas[/COLOR]' % oo00O00oO , o00oooO0Oo , 151 , IIIII , oo00 )
 iIIII1iIIii ( '[COLOR %s]Series Retro[/COLOR]' % oo00O00oO , o00oooO0Oo , 152 , ooooooO0oo , oo00 )
 iIIII1iIIii ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 142 , I11i1 , oo00 )
 if 89 - 89: iI + o0oO0 * iI / iI
def II1II1iIIi11 ( ) :
 if 46 - 46: OoOO
 O0000 = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 ooO00O0O0 = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oOOOO = O0000 + ooO00O0O0
 iII1I1 = '[\'"](.*?)[\'"]'
 iIII1i1i = ooO ( oOOOO )
 ii = re . compile ( iII1I1 ) . findall ( iIII1i1i )
 for o0Ooo0o0ooo0 in ii :
  try :
   if 70 - 70: i11iIiiIii % O0ooOooooO
   if o0Ooo0o0ooo0 == 'si' :
    if 11 - 11: i1I111II1I % o00O0oo % o0oO0 / II111iiii % Oooo0Ooo000 - ii11ii1ii
    iIIII1iIIii ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , OOOO , oo00 )
    if 96 - 96: o00O0oo / II111iiii . o0oO0 - O0ooOooooO * O0oO * oO0o0ooO0
   elif o0Ooo0o0ooo0 == 'no' :
    if 76 - 76: o0oO0 - II111iiii * IIII / OoooooooOO
    iIIII1iIIii ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , oOoOooOo0o0 , oo00 )
    if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
   return
   if 71 - 71: OoooooooOO
  except :
   pass
   if 33 - 33: Oooo0Ooo000
def OOO0ooo ( ) :
 if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
 if 22 - 22: iI - iI % IIII . Oooo0Ooo000 + oO0o0ooO0
 try :
  if 63 - 63: OOooOOo % Oooo0Ooo000 * o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % O0ooOooooO
  iiI1i1Iii111 = ooO ( OOoOooOoOOOoo )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 43 - 43: o0000oOoOoO0o
   try :
    if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
    oOOOo = OO0O0Ooo
    Oo00o0OO0O00o = xbmc . Keyboard ( '' , 'Buscar' )
    Oo00o0OO0O00o . doModal ( )
    if ( Oo00o0OO0O00o . isConfirmed ( ) ) :
     O0Oooo = xbmcgui . DialogProgress ( )
     O0Oooo . create ( 'Realstream:' , 'Buscando ...' )
     iiIi1i = range ( 0 , 69 )
     for I1i11111i1i11 in iiIi1i :
      I1i11111i1i11 = I1i11111i1i11 + 1
     I1ii11 = urllib . quote_plus ( Oo00o0OO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     oOoOoOoo0 = ooO ( oOOOo )
     ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
     for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
      O0Oooo . update ( I1i11111i1i11 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % Ii1i1iI )
      xbmc . sleep ( 5 )
      if O0Oooo . iscanceled ( ) : break ;
      if re . search ( I1ii11 , i1ii1II1ii ( Ii1i1iI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 31 - 31: o0oO0
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
       O0Oooo . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       O0Oooo . close ( )
     iIIII1iIIii ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + I1ii11 + "[/COLOR] , 2000)" )
     if 68 - 68: O0oO % Oooo0Ooo000 + o00O0oo - i11iIiiIii . o0000oOoOoO0o - Oooo0Ooo000
     if 31 - 31: OOooOOo * oO0o0ooO0 + OoooooooOO - O0ooOooooO / OoooooooOO
   except : iIIII1iIIii ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
   if 19 - 19: i1I111II1I * iI * o0000oOoOoO0o + O0 / O0
 except :
  pass
  if 73 - 73: iIii1I11I1II1 / iIii1I11I1II1 - oO0o0ooO0
def oOoOOOo ( ) :
 if 43 - 43: i1IIi
 try :
  if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
  iiI1i1Iii111 = ooO ( O00Ooo )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
   try :
    if 8 - 8: o0000oOoOoO0o
    oOOOo = OO0O0Ooo
    if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
   except :
    pass
    if 78 - 78: o0oO0 / II111iiii % OoOO0ooOOoo0O
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
  for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
   try :
    if 52 - 52: IIII - O0ooOooooO * oO0o0ooO0
    iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
    if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 36 - 36: O0 + ii11ii1ii
def iIIIi1i1I11i ( ) :
 if 55 - 55: ii11ii1ii - IIII
 try :
  if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
  iiI1i1Iii111 = ooO ( oO00O0 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
   try :
    if 72 - 72: i1IIi
    oOOOo = OO0O0Ooo
    if 82 - 82: OoOO0ooOOoo0O + OoooooooOO / i11iIiiIii * o00O0oo . OoooooooOO
   except :
    pass
    if 63 - 63: o00O0oo
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
  for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
   try :
    if 6 - 6: iI / o00O0oo
    iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
    if 57 - 57: O0oO
   except :
    pass
 except :
  pass
  if 67 - 67: OoOO . iI
  if 87 - 87: oO0o0ooO0 % o0oO0
def oo0OOOoOo ( ) :
 if 21 - 21: OoOO - O0 . oO0o0ooO0 + o0oO0 . iIii1I11I1II1 - OoOO0ooOOoo0O
 try :
  if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
  iiI1i1Iii111 = ooO ( O0O0Oo00 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 53 - 53: o0oO0 % ii11ii1ii
   try :
    if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
    oOOOo = OO0O0Ooo
    if 41 - 41: o0oO0 % o00O0oo
   except :
    pass
    if 12 - 12: IIII
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
  for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
   try :
    if 69 - 69: OoooooooOO + IIII
    iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
    if 26 - 26: ii11ii1ii + IIII / OoOO % OoOO0ooOOoo0O % o00O0oo + II111iiii
   except :
    pass
 except :
  pass
  if 31 - 31: O0oO % IIII * O0oO
def IiI ( ) :
 if 34 - 34: O0oO % iI . O0 . iIii1I11I1II1
 try :
  if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
  iiI1i1Iii111 = ooO ( I1ii1ii11i1I )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 99 - 99: O0oO - Oooo0Ooo000 - oO0o0ooO0 % OoOO
   try :
    if 21 - 21: II111iiii % o00O0oo . i1IIi - OoooooooOO
    oOOOo = OO0O0Ooo
    if 4 - 4: OoooooooOO . iI
   except :
    pass
    if 78 - 78: o00O0oo + O0oO - O0
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
  for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
   try :
    if 10 - 10: Oooo0Ooo000 % OOooOOo
    iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
    if 97 - 97: OoooooooOO - Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 + O0
def I111I11I111 ( ) :
 if 46 - 46: i11iIiiIii - O0 . oO0o0ooO0
 try :
  if 100 - 100: OOooOOo / o0000oOoOoO0o * O0ooOooooO . O0 / IIII
  iiI1i1Iii111 = ooO ( OOoOooOoOOOoo )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1i1Iii111 )
  for OO0O0Ooo in ii :
   if 83 - 83: Oooo0Ooo000
   try :
    if 48 - 48: II111iiii * IIII * Oooo0Ooo000
    oOOOo = OO0O0Ooo
    if 50 - 50: i1I111II1I % i1IIi
   except :
    pass
    if 21 - 21: OoooooooOO - iIii1I11I1II1
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( OO ) . findall ( oOoOoOoo0 )
  for OO0O0o0o0 , Ii1i1iI , oo00 , IIiI1 , ii1I1IiiI1ii1i in ii :
   try :
    if 93 - 93: oO0o0ooO0 - o0000oOoOoO0o % OoOO0ooOOoo0O . OoOO0ooOOoo0O - iI
    iIIiI1I1i ( Ii1i1iI , IIiI1 , 143 , OO0O0o0o0 , oo00 , ii1I1IiiI1ii1i )
    if 90 - 90: iI + II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 40 - 40: iI / OoOO0ooOOoo0O % i11iIiiIii % o00O0oo / OOooOOo
def ooOOOOo0 ( name , url ) :
 if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 96 - 96: O0ooOooooO
 i1I11iIII1i1I = ooO ( url )
 ii = re . compile ( iiIi1IIi1I ) . findall ( i1I11iIII1i1I )
 for OO0O0o0o0 , name , oo00 , url in ii :
  try :
   if 63 - 63: ii11ii1ii + Oooo0Ooo000 - II111iiii
   if 2 - 2: i1I111II1I
   oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
   oOo0O0O0 ( name , url , 144 , OO0O0o0o0 , oo00 )
   if 89 - 89: oO0o0ooO0 / OoooooooOO . O0ooOooooO
   if 34 - 34: O0ooOooooO - OoooooooOO . OOooOOo / II111iiii
  except :
   pass
   if 27 - 27: OoOO / ii11ii1ii * iI - OoOO
   if 19 - 19: O0oO
   if 67 - 67: O0 % iIii1I11I1II1 / i1I111II1I . i11iIiiIii - o0oO0 + O0
def oOo0O0O0 ( name , url , mode , iconimage , fanart ) :
 if 27 - 27: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 89 - 89: II111iiii / oO0o0ooO0
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 35 - 35: Oooo0Ooo000 . OoOO0ooOOoo0O * i11iIiiIii
 if 44 - 44: i11iIiiIii / ii11ii1ii
def Ii1IIi ( name , url ) :
 if 43 - 43: Oooo0Ooo000 % O0ooOooooO
 if 69 - 69: O0ooOooooO % OoOO
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiI1I1 = ooO ( oOO0O00Oo0O0o )
 ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
 for iIi11ii in ii :
  if 50 - 50: o0oO0 / OoOO0ooOOoo0O * o0oO0
  try :
   if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
   if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 32 - 32: i11iIiiIii - Oooo0Ooo000
   if 53 - 53: OoooooooOO - i1I111II1I
   if O00O0oOO00O00 == iIi11ii :
    if 87 - 87: oO0o0ooO0 . OOooOOo
    if 17 - 17: o0oO0 . i11iIiiIii
    if 'https://team.com' in url :
     if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 63 - 63: oO0o0ooO0
    if 'https://mybox.com' in url :
     if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 36 - 36: i1I111II1I
     if 49 - 49: IIII / OoooooooOO / OOooOOo
    if 'https://vidcloud.co/' in url :
     if 74 - 74: Oooo0Ooo000 % o00O0oo
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 7 - 7: II111iiii
    if 'https://gounlimited.to' in url :
     if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    if 'https://drive.com' in url :
     if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 49 - 49: o00O0oo
     if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    import resolveurl
    if 21 - 21: O0 * O0 % o00O0oo
    o00ooo = urlresolver . HostedMediaFile ( url )
    if 31 - 31: O0 * o0000oOoOoO0o % o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
    if not o00ooo :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 11 - 11: OoOO0ooOOoo0O + i1I111II1I - OoooooooOO / OoOO
    try :
     O0Oooo = xbmcgui . DialogProgress ( )
     O0Oooo . create ( 'Realstream:' , 'Iniciando ...' )
     O0Oooo . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     iIIi1iI1I1IIi = o00ooo . resolve ( )
     if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
      try : O0OO0 = iIIi1iI1I1IIi . msg
      except : O0OO0 = url
      raise Exception ( O0OO0 )
      if 99 - 99: iI - OOooOOo / i1I111II1I / i11iIiiIii
    except Exception as IiIi1ii111i1 :
     try : O0OO0 = str ( IiIi1ii111i1 )
     except : O0OO0 = url
     O0Oooo . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     O0Oooo . close ( )
     if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
    O0Oooo . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    O0Oooo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    O0Oooo . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    O0Oooo . close ( )
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 91 - 91: O0oO / O0 - o0oO0 . OOooOOo
    if 82 - 82: i1I111II1I * IIII / oO0o0ooO0
   else :
    if 2 - 2: OOooOOo + o0000oOoOoO0o . o0000oOoOoO0o . O0 / O0oO
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 40 - 40: o0000oOoOoO0o - II111iiii / ii11ii1ii
     oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     iIIII1iIIii ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 14 - 14: o00O0oo
   if 5 - 5: o0000oOoOoO0o . iIii1I11I1II1 % iIii1I11I1II1
   if 56 - 56: OoooooooOO - O0oO - i1IIi
   if 8 - 8: Oooo0Ooo000 / IIII . OOooOOo + o00O0oo / i11iIiiIii
   if 31 - 31: iI - iIii1I11I1II1 + O0ooOooooO . ii11ii1ii / i1I111II1I % iIii1I11I1II1
def I11i1iIiiIiIi ( ) :
 if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
 if 62 - 62: IIII
 i1I1i = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 i1I1i . doModal ( )
 if not i1I1i . isConfirmed ( ) :
  return None ;
 Ii1i1iI = i1I1i . getText ( ) . strip ( )
 if 87 - 87: ii11ii1ii / O0 * i1I111II1I / o0000oOoOoO0o
 if 19 - 19: Oooo0Ooo000 + i1IIi . OOooOOo - ii11ii1ii
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 16 - 16: oO0o0ooO0 + iI / o0000oOoOoO0o
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Ii1i1iI + '&language=es-ES' ) )
  if 62 - 62: i1IIi / iI . OOooOOo * o0000oOoOoO0o
  if 21 - 21: o0000oOoOoO0o
  return 'android'
  if 81 - 81: O0oO / iIii1I11I1II1 - iI * Oooo0Ooo000 . OOooOOo * o00O0oo
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 95 - 95: OOooOOo
  O00oOoo0OoO0 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Ii1i1iI + '&language=es-ES' )
  if 88 - 88: i1I111II1I % OoOO + Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
  if 78 - 78: OoooooooOO
  return 'windows'
  if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
  if 48 - 48: O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
def IiI1i111IiIiIi1 ( ) :
 if 39 - 39: O0oO - o00O0oo
 try :
  if 53 - 53: o0000oOoOoO0o % O0ooOooooO + iI . ii11ii1ii - o00O0oo % o0000oOoOoO0o
  iiI1I1 = ooO ( O0O0ooOOO )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 64 - 64: II111iiii
   try :
    if 40 - 40: OoOO0ooOOoo0O % OoOO
    all = OO0O0Ooo
    if 62 - 62: o0000oOoOoO0o
   except :
    pass
    if 15 - 15: O0oO + o0oO0 . IIII * OoOO . OoOO0ooOOoo0O
  i1I11iIII1i1I = ooO ( all )
  ii = re . compile ( O000OOOOOo ) . findall ( i1I11iIII1i1I )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    if 18 - 18: i1IIi % II111iiii + Oooo0Ooo000 % o0oO0
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 72 - 72: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 45 - 45: ii11ii1ii - o0000oOoOoO0o % Oooo0Ooo000
def i1IIi1i1Ii1 ( ) :
 if 45 - 45: iIii1I11I1II1 . oO0o0ooO0 / OoOO0ooOOoo0O / i1I111II1I
 try :
  if 55 - 55: i1I111II1I
  i1111 = ooO ( iIiIi11 )
  ii = re . compile ( Ii1I1Ii ) . findall ( i1111 )
  for OO0O0Ooo in ii :
   if 24 - 24: OoOO + oO0o0ooO0 . o0000oOoOoO0o / oO0o0ooO0
   try :
    if 56 - 56: iIii1I11I1II1 . i11iIiiIii - IIII * II111iiii * Oooo0Ooo000
    oOOOo = OO0O0Ooo
    if 5 - 5: IIII / IIII - o00O0oo
   except :
    pass
    if 79 - 79: o00O0oo + Oooo0Ooo000
  oOoOoOoo0 = ooO ( oOOOo )
  ii = re . compile ( O000OOOOOo ) . findall ( oOoOoOoo0 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    if 10 - 10: ii11ii1ii + O0
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 43 - 43: iIii1I11I1II1 / II111iiii % o0000oOoOoO0o - IIII
   except :
    pass
 except :
  pass
  if 62 - 62: O0oO
def O000oOo ( ) :
 if 53 - 53: iIii1I11I1II1 + o0000oOoOoO0o - OoOO0ooOOoo0O - oO0o0ooO0 / iI % i11iIiiIii
 try :
  if 3 - 3: O0ooOooooO . iI % OOooOOo + o00O0oo
  i11 = ooO ( iiiiI )
  ii = re . compile ( Ii1I1Ii ) . findall ( i11 )
  for OO0O0Ooo in ii :
   if 64 - 64: i1IIi
   try :
    IIii1 = OO0O0Ooo
   except :
    pass
    if 35 - 35: i11iIiiIii - OOooOOo / IIII + o0oO0 * oO0o0ooO0
  iiI1I1 = ooO ( IIii1 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    if 49 - 49: o0000oOoOoO0o * o0oO0 + O0oO + O0ooOooooO
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 30 - 30: o0000oOoOoO0o / IIII / i1I111II1I % iI + II111iiii
   except :
    pass
 except :
  pass
  if 4 - 4: O0ooOooooO - ii11ii1ii - i1I111II1I - O0oO % i11iIiiIii / OoOO
def i1iii11 ( ) :
 if 92 - 92: OoOO0ooOOoo0O . OoooooooOO - Oooo0Ooo000
 try :
  if 74 - 74: iIii1I11I1II1 % O0ooOooooO * IIII * iIii1I11I1II1
  iiI1I1 = ooO ( db2 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 73 - 73: o0000oOoOoO0o % Oooo0Ooo000 . IIII
   try :
    if 60 - 60: OoOO0ooOOoo0O
    IiIi1iiii = OO0O0Ooo
    if 45 - 45: iIii1I11I1II1
   except :
    pass
    if 28 - 28: oO0o0ooO0
    if 52 - 52: OOooOOo + iIii1I11I1II1
  iiI1I1 = ooO ( IiIi1iiii )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 71 - 71: O0 / oO0o0ooO0
   except :
    pass
 except :
  pass
  if 34 - 34: OoOO0ooOOoo0O . iIii1I11I1II1 % O0
def iI11Ii111 ( ) :
 if 54 - 54: OoOO0ooOOoo0O % O0ooOooooO . OoOO0ooOOoo0O * IIII + OoOO0ooOOoo0O % i1IIi
 try :
  if 23 - 23: Oooo0Ooo000 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
  iIii11iI1II = ooO ( Oo0o0O00 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iIii11iI1II )
  for OO0O0Ooo in ii :
   if 42 - 42: iI - OOooOOo + o00O0oo % o0oO0
   try :
    if 44 - 44: i1IIi - O0 - o00O0oo * o00O0oo + OoOO0ooOOoo0O
    O0oo = OO0O0Ooo
    if 82 - 82: OoOO0ooOOoo0O + O0 - i1I111II1I % oO0o0ooO0 * i11iIiiIii
   except :
    pass
    if 15 - 15: o0000oOoOoO0o
    if 39 - 39: IIII / o00O0oo / OOooOOo * Oooo0Ooo000
  iiI1I1 = ooO ( O0oo )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    if 44 - 44: O0 + iI . iIii1I11I1II1 + ii11ii1ii / O0 - O0oO
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 83 - 83: i1I111II1I * O0oO / ii11ii1ii
   except :
    pass
 except :
  pass
  if 32 - 32: o0000oOoOoO0o + OoOO0ooOOoo0O - OoooooooOO
def Ii11iii1II1i ( ) :
 if 65 - 65: o0oO0 + OoOO - OoooooooOO
 try :
  if 51 - 51: ii11ii1ii + oO0o0ooO0 / O0ooOooooO - i1IIi
  iiI1I1 = ooO ( OOoO )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 51 - 51: ii11ii1ii - o00O0oo * O0oO
   try :
    if 12 - 12: iIii1I11I1II1 % iI % iI
    o0i1iI1iiI1I = OO0O0Ooo
    if 52 - 52: OoOO % o0oO0 * II111iiii
   except :
    pass
    if 4 - 4: O0oO % O0 - OoooooooOO + iI . oO0o0ooO0 % II111iiii
    if 9 - 9: II111iiii * II111iiii . i11iIiiIii * iIii1I11I1II1
  iiI1I1 = ooO ( o0i1iI1iiI1I )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 18 - 18: OoOO . II111iiii % OoOO0ooOOoo0O % o0oO0
   except :
    pass
 except :
  pass
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
def OOOo ( ) :
 if 74 - 74: o0oO0 - OoooooooOO . ii11ii1ii
 try :
  if 31 - 31: o0000oOoOoO0o % O0oO + iIii1I11I1II1 + i11iIiiIii * Oooo0Ooo000
  iiI1I1 = ooO ( iiIiI1i1 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 45 - 45: IIII * Oooo0Ooo000 . iI - Oooo0Ooo000 + i1I111II1I
   try :
    if 34 - 34: IIII . ii11ii1ii
    OOoO0oO00o = OO0O0Ooo
    if 10 - 10: OoOO
   except :
    pass
    if 22 - 22: i11iIiiIii / O0
  iiI1I1 = ooO ( OOoO0oO00o )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 94 - 94: iI * O0oO - i1I111II1I . iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 66 - 66: iI - IIII * OoOO0ooOOoo0O / oO0o0ooO0 * II111iiii * OoOO
def Ooo0OiiII1IiIi1iI1 ( ) :
 if 72 - 72: O0
 try :
  if 58 - 58: i1I111II1I + iIii1I11I1II1
  iiI1I1 = ooO ( IiIi11iI )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 65 - 65: II111iiii - Oooo0Ooo000 % o0000oOoOoO0o - OoOO0ooOOoo0O * O0ooOooooO + o0oO0
   try :
    if 79 - 79: iI . OoOO0ooOOoo0O % Oooo0Ooo000 - ii11ii1ii
    o0oO0oO0O = OO0O0Ooo
    if 18 - 18: ii11ii1ii
   except :
    pass
    if 20 - 20: oO0o0ooO0 * O0 + O0oO - OoooooooOO . O0oO
    if 60 - 60: o0000oOoOoO0o . o0000oOoOoO0o / O0ooOooooO
  iiI1I1 = ooO ( o0oO0oO0O )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 45 - 45: O0 . i11iIiiIii % O0ooOooooO . OoOO0ooOOoo0O % i1I111II1I % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 . OoOO0ooOOoo0O - i11iIiiIii * iIii1I11I1II1 % i11iIiiIii / OOooOOo
def oO0o ( ) :
 if 50 - 50: O0ooOooooO / O0ooOooooO + IIII * iI / o00O0oo
 try :
  if 14 - 14: o0oO0 % OOooOOo - iIii1I11I1II1 . IIII + OoOO - Oooo0Ooo000
  iiI1I1 = ooO ( i11I1IiII1i1i )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 5 - 5: O0ooOooooO
   try :
    if 62 - 62: OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * O0ooOooooO
    OOOOOo = OO0O0Ooo
    if 50 - 50: o0oO0 - i11iIiiIii + iIii1I11I1II1 / O0 - o0oO0 + o0000oOoOoO0o
   except :
    pass
    if 22 - 22: II111iiii - o0oO0 / iI % OoooooooOO + IIII
    if 5 - 5: OoOO / O0ooOooooO + i11iIiiIii % O0oO
  iiI1I1 = ooO ( OOOOOo )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
def oOO0 ( ) :
 if 15 - 15: ii11ii1ii + O0oO . iI - iIii1I11I1II1 / O0 % iIii1I11I1II1
 try :
  if 86 - 86: OOooOOo / oO0o0ooO0 * o0oO0
  iiI1I1 = ooO ( I1111i )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 64 - 64: iI / O0 * OoOO0ooOOoo0O * iI
   try :
    if 60 - 60: O0oO / i1IIi % o00O0oo / o00O0oo * o00O0oo . i11iIiiIii
    o0oOO00 = OO0O0Ooo
    if 46 - 46: i11iIiiIii - O0oO
   except :
    pass
    if 95 - 95: II111iiii
    if 65 - 65: OoOO0ooOOoo0O
  iiI1I1 = ooO ( o0oOO00 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 31 - 31: O0oO * OoOO0ooOOoo0O . i1I111II1I % o0oO0 + ii11ii1ii
   except :
    pass
 except :
  pass
  if 47 - 47: O0 * OOooOOo * OoOO . II111iiii
def O0o00o000oO ( ) :
 if 62 - 62: o00O0oo / O0oO . i1IIi
 try :
  if 99 - 99: OoOO0ooOOoo0O . Oooo0Ooo000
  iiI1I1 = ooO ( OOo0O0oo0OO0O )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 59 - 59: O0oO / ii11ii1ii / IIII / O0 / OoOO0ooOOoo0O + o0000oOoOoO0o
   try :
    if 13 - 13: o0000oOoOoO0o % oO0o0ooO0 / Oooo0Ooo000 % Oooo0Ooo000 % O0
    o0Ii1 = OO0O0Ooo
    if 50 - 50: oO0o0ooO0 - iI / iIii1I11I1II1 - OoOO + II111iiii - O0
   except :
    pass
    if 88 - 88: oO0o0ooO0 * OoOO
    if 35 - 35: o00O0oo / O0ooOooooO % OOooOOo + iIii1I11I1II1
  iiI1I1 = ooO ( o0Ii1 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 79 - 79: OoOO0ooOOoo0O / iI
   except :
    pass
 except :
  pass
  if 77 - 77: ii11ii1ii
  if 46 - 46: Oooo0Ooo000
def o00OoooooooOo ( ) :
 if 32 - 32: o0000oOoOoO0o + OOooOOo . Oooo0Ooo000
 try :
  if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
  iiI1I1 = ooO ( o00O0O )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 98 - 98: OoOO0ooOOoo0O % II111iiii
   try :
    if 95 - 95: iIii1I11I1II1 - Oooo0Ooo000 - IIII + Oooo0Ooo000 % o00O0oo . OOooOOo
    IiiIIi1 = OO0O0Ooo
    if 28 - 28: o0000oOoOoO0o
   except :
    pass
    if 45 - 45: o0000oOoOoO0o . OOooOOo / Oooo0Ooo000 - ii11ii1ii * iIii1I11I1II1
    if 86 - 86: II111iiii + iI + i1I111II1I
  iiI1I1 = ooO ( IiiIIi1 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 9 - 9: iI + II111iiii % iI % i1I111II1I + iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 59 - 59: i1IIi
  if 48 - 48: O0 * o0oO0 * OoOO . OoOO * O0oO - o0oO0
def iIi11i ( ) :
 if 56 - 56: i11iIiiIii . iI / O0ooOooooO
 try :
  if 48 - 48: OoOO * IIII + iIii1I11I1II1 / II111iiii
  iiI1I1 = ooO ( Iii1I1111ii )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 100 - 100: O0oO
   try :
    if 59 - 59: oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
    ooooO = OO0O0Ooo
    if 92 - 92: o0000oOoOoO0o / o0000oOoOoO0o * o0oO0
   except :
    pass
    if 19 - 19: o0oO0
    if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
  iiI1I1 = ooO ( ooooO )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
   except :
    pass
    if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
 except :
  pass
  if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
  if 71 - 71: O0ooOooooO
def Iii ( ) :
 if 14 - 14: IIII
 try :
  if 79 - 79: o0oO0
  iiI1I1 = ooO ( Ii1IIiI1i )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 76 - 76: iIii1I11I1II1
   try :
    if 80 - 80: iIii1I11I1II1 . O0 / o0oO0 % o0oO0
    ooOo000OoO0o = OO0O0Ooo
    if 58 - 58: o00O0oo
   except :
    pass
    if 2 - 2: II111iiii / Oooo0Ooo000
    if 54 - 54: i1IIi . O0oO - o00O0oo + iI + ii11ii1ii / ii11ii1ii
  iiI1I1 = ooO ( ooOo000OoO0o )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 22 - 22: iI . iIii1I11I1II1
   except :
    pass
    if 12 - 12: o0oO0
 except :
  pass
  if 71 - 71: OOooOOo . II111iiii . OOooOOo - iI
def I1ii1 ( ) :
 if 48 - 48: iI / iIii1I11I1II1 + IIII + iIii1I11I1II1 . OoOO
 try :
  if 60 - 60: Oooo0Ooo000
  iiI1I1 = ooO ( IiII111i1i11 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 98 - 98: iI
   try :
    if 34 - 34: iIii1I11I1II1 * O0oO * O0oO / o00O0oo
    IIIIIIi1i = OO0O0Ooo
    if 26 - 26: iIii1I11I1II1 - O0 . O0
   except :
    pass
    if 68 - 68: IIII + oO0o0ooO0 . O0 . o0oO0 % i1IIi % IIII
  iiI1I1 = ooO ( IIIIIIi1i )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 50 - 50: i1I111II1I + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 96 - 96: OoOO
  if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
def oOo0Oo0O0O ( ) :
 if 48 - 48: ii11ii1ii - iI + ii11ii1ii - OOooOOo * i11iIiiIii . O0ooOooooO
 try :
  if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
  iiI1I1 = ooO ( oooO )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
   try :
    if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
    O0OOOOOO0 = OO0O0Ooo
    if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
    if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
    if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
  iiI1I1 = ooO ( O0OOOOOO0 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
   except :
    pass
 except :
  pass
  if 15 - 15: IIII
  if 31 - 31: O0ooOooooO / i1IIi . OoOO
def OOOoo ( ) :
 if 25 - 25: o00O0oo + oO0o0ooO0 + OoooooooOO . II111iiii . O0ooOooooO
 try :
  if 66 - 66: iI * OoOO0ooOOoo0O
  iiI1I1 = ooO ( ooo )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 2 - 2: oO0o0ooO0 . Oooo0Ooo000 * ii11ii1ii + O0 - O0oO * iIii1I11I1II1
   try :
    if 12 - 12: o0000oOoOoO0o * Oooo0Ooo000 % II111iiii * i1IIi * iIii1I11I1II1
    oO0oOoo0O = OO0O0Ooo
    if 26 - 26: ii11ii1ii + OOooOOo * IIII + iI
   except :
    pass
  iiI1I1 = ooO ( oO0oOoo0O )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 88 - 88: O0oO + i11iIiiIii % oO0o0ooO0 * IIII * IIII * o0oO0
   except :
    pass
 except :
  pass
  if 24 - 24: iI / O0ooOooooO + i1I111II1I . i1I111II1I
def I1ii1i ( ) :
 if 22 - 22: oO0o0ooO0 * o0oO0 * i11iIiiIii + O0ooOooooO * OoOO0ooOOoo0O * OoOO
 try :
  if 85 - 85: O0ooOooooO * IIII % ii11ii1ii - O0ooOooooO - O0oO
  iiI1I1 = ooO ( Ooo0oOooo0 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 46 - 46: O0
   try :
    if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
    O0000oO0o00 = OO0O0Ooo
    if 80 - 80: OoooooooOO + i1I111II1I
   except :
    pass
    if 95 - 95: Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * OoooooooOO % OoOO
    if 43 - 43: ii11ii1ii . Oooo0Ooo000
  iiI1I1 = ooO ( O0000oO0o00 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
   except :
    pass
 except :
  pass
  if 29 - 29: i1I111II1I . iI - II111iiii
  if 68 - 68: iIii1I11I1II1 + II111iiii / oO0o0ooO0
def oOooo00000 ( ) :
 if 26 - 26: O0
 try :
  if 34 - 34: iI * Oooo0Ooo000
  iiI1I1 = ooO ( iiIiIIIiiI )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 97 - 97: i11iIiiIii % oO0o0ooO0 / ii11ii1ii / ii11ii1ii
   try :
    if 97 - 97: II111iiii - Oooo0Ooo000 - iIii1I11I1II1 * OOooOOo
    oooO0o0O0oo0o = OO0O0Ooo
    if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
   except :
    pass
    if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
    if 49 - 49: i1I111II1I * O0 . i1I111II1I
  iiI1I1 = ooO ( oooO0o0O0oo0o )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 19 - 19: II111iiii - i1I111II1I
   except :
    pass
 except :
  pass
  if 59 - 59: o0000oOoOoO0o * OoOO - o0oO0 . IIII
def o0OO00oo0O ( ) :
 if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
 try :
  if 5 - 5: O0 / iI . ii11ii1ii + OoooooooOO
  iiI1I1 = ooO ( II11IiIi11 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 97 - 97: i1I111II1I . o0oO0 . o0oO0 / iIii1I11I1II1 - OoOO + O0ooOooooO
   try :
    if 32 - 32: IIII . o0000oOoOoO0o % i1I111II1I + o00O0oo + OoOO
    OOOoOOo0o = OO0O0Ooo
    if 50 - 50: II111iiii - Oooo0Ooo000 + iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 91 - 91: II111iiii - O0 . iIii1I11I1II1 . O0 + o00O0oo - II111iiii
    if 26 - 26: o0000oOoOoO0o
  iiI1I1 = ooO ( OOOoOOo0o )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   except :
    pass
 except :
  pass
  if 46 - 46: II111iiii - i1I111II1I * OoooooooOO / oO0o0ooO0 % i1I111II1I
  if 11 - 11: iIii1I11I1II1 . OoOO0ooOOoo0O / i1I111II1I % iI
def o0O00Oooo ( ) :
 if 12 - 12: iI
 try :
  if 86 - 86: oO0o0ooO0 - OoOO
  iiI1I1 = ooO ( I1iiii1I )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 63 - 63: OOooOOo / OoOO0ooOOoo0O + OoooooooOO . O0oO . iI
   try :
    if 48 - 48: i1IIi - O0ooOooooO - i11iIiiIii . O0oO - O0ooOooooO * O0oO
    OOOOO = OO0O0Ooo
    if 68 - 68: O0oO + OoOO - O0 / OoOO * OoOO0ooOOoo0O
   except :
    pass
    if 50 - 50: IIII + II111iiii . OOooOOo / i1IIi / OOooOOo * oO0o0ooO0
    if 85 - 85: II111iiii . iI % IIII % O0oO
  iiI1I1 = ooO ( OOOOO )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * O0ooOooooO . i11iIiiIii * O0
  if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
def iI111II1ii ( ) :
 if 62 - 62: O0ooOooooO * iIii1I11I1II1 . i1I111II1I - OoooooooOO * II111iiii
 try :
  if 45 - 45: O0 % OOooOOo - O0ooOooooO . OoOO
  iiI1I1 = ooO ( oO00ooooO0o )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 42 - 42: O0ooOooooO / o0000oOoOoO0o + ii11ii1ii . ii11ii1ii % IIII
   try :
    if 16 - 16: i1IIi + OoOO % OoOO0ooOOoo0O + o0oO0 * ii11ii1ii
    i1o0oo0 = OO0O0Ooo
    if 67 - 67: O0 * O0oO - o0000oOoOoO0o - II111iiii
   except :
    pass
    if 41 - 41: OOooOOo - Oooo0Ooo000 % II111iiii . Oooo0Ooo000 - O0oO
    if 45 - 45: o0oO0 - IIII
  iiI1I1 = ooO ( i1o0oo0 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
   except :
    pass
 except :
  pass
  if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
def I111I1I ( ) :
 if 54 - 54: II111iiii + O0oO % O0oO % o0000oOoOoO0o
 try :
  if 25 - 25: O0ooOooooO - ii11ii1ii
  iiI1I1 = ooO ( o0oO0oooOoo )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 10 - 10: O0 % i1I111II1I . OoOO + o0000oOoOoO0o + o00O0oo
   try :
    if 52 - 52: OoOO0ooOOoo0O / OoOO + Oooo0Ooo000
    Iii1i11iiI1 = OO0O0Ooo
    if 95 - 95: oO0o0ooO0 * iIii1I11I1II1 + o00O0oo
   except :
    pass
    if 5 - 5: ii11ii1ii
    if 100 - 100: o0oO0 + iIii1I11I1II1
  iiI1I1 = ooO ( Iii1i11iiI1 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 59 - 59: i1I111II1I
   except :
    pass
 except :
  pass
  if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
def ii1IIiII111I ( ) :
 if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
 try :
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  iiI1I1 = ooO ( I1i111I )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 79 - 79: i1I111II1I % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
    iiiiiI = OO0O0Ooo
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
   except :
    pass
    if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
  iiI1I1 = ooO ( iiiiiI )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 47 - 47: OoOO + i1I111II1I / II111iiii
   except :
    pass
 except :
  pass
  if 97 - 97: o00O0oo / OOooOOo % O0 + i1IIi - iI
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
def o0OOOOOo0 ( ) :
 if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 56 - 56: oO0o0ooO0 + iI
  iiI1I1 = ooO ( I1i11 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 32 - 32: II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
   try :
    if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
    Ooo000O00 = OO0O0Ooo
    if 36 - 36: IIII % i11iIiiIii
   except :
    pass
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
    if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
  iiI1I1 = ooO ( Ooo000O00 )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 83 - 83: o00O0oo * o00O0oo + IIII
   except :
    pass
 except :
  pass
  if 57 - 57: O0 - O0 . o00O0oo / o0000oOoOoO0o / o0oO0
def I1IiII1I1i1I1 ( ) :
 if 28 - 28: ii11ii1ii + i1I111II1I % II111iiii / OoOO + i11iIiiIii
 try :
  if 20 - 20: o00O0oo
  iiI1I1 = ooO ( IiIIi1 )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 3 - 3: OoOO * i1IIi . OOooOOo . O0 - OoOO0ooOOoo0O
   try :
    if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
    I1I1IIiiii1ii = OO0O0Ooo
    if 92 - 92: oO0o0ooO0 / IIII . o00O0oo
   except :
    pass
  iiI1I1 = ooO ( I1I1IIiiii1ii )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 30 - 30: o0oO0 . o00O0oo / IIII
   except :
    pass
 except :
  pass
  if 2 - 2: i1I111II1I % OOooOOo - Oooo0Ooo000
def oooOo ( ) :
 if 79 - 79: oO0o0ooO0 - II111iiii
 try :
  if 43 - 43: i1IIi + O0 % OoOO / o0oO0 * OOooOOo
  iiI1I1 = ooO ( II1i11I )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 89 - 89: OOooOOo . ii11ii1ii + o00O0oo . O0 % o0000oOoOoO0o
   try :
    if 84 - 84: OoooooooOO + Oooo0Ooo000 / OOooOOo % IIII % o00O0oo * OOooOOo
    OOoO0oooo = OO0O0Ooo
    if 24 - 24: O0oO / OOooOOo * i1IIi % OoooooooOO
   except :
    pass
  iiI1I1 = ooO ( OOoO0oooo )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
   except :
    pass
 except :
  pass
  if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
def Ii1I1i1ii1I1 ( ) :
 if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
 try :
  if 25 - 25: oO0o0ooO0
  iiI1I1 = ooO ( OoOOoooOO0O )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
   try :
    if 89 - 89: OoOO0ooOOoo0O . IIII
    IIIIIiI11Ii = OO0O0Ooo
    if 41 - 41: i11iIiiIii - i1IIi / ii11ii1ii * i1I111II1I / Oooo0Ooo000 - ii11ii1ii
   except :
    pass
  iiI1I1 = ooO ( IIIIIiI11Ii )
  ii = re . compile ( O000OOOOOo ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 , id , i1iI1 , ii1I1IiiI1ii1i , oo00 in ii :
   try :
    O00OoOO0oo0 ( Ii1i1iI , IIiI1 , III1ii1I , id , i1iI1 , ii1I1IiiI1ii1i , oo00 )
    if 56 - 56: O0
   except :
    pass
 except :
  pass
  if 45 - 45: OoOO0ooOOoo0O - OoOO - OoOO0ooOOoo0O
def IIiiI ( ) :
 if 36 - 36: O0ooOooooO
 try :
  if 52 - 52: Oooo0Ooo000 % O0 . i1IIi . OoooooooOO
  iiI1I1 = ooO ( O0o0oO )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for OO0O0Ooo in ii :
   if 33 - 33: IIII % II111iiii
   try :
    if 71 - 71: o0oO0 * Oooo0Ooo000 % II111iiii . o0oO0 % OoOO + o00O0oo
    o0oOo0OO = OO0O0Ooo
    if 79 - 79: OoOO0ooOOoo0O % OOooOOo % o0oO0 / i1IIi % OoOO
   except :
    pass
  iiI1I1 = ooO ( o0oOo0OO )
  ii = re . compile ( o0o0o0oO0oOO ) . findall ( iiI1I1 )
  for III1ii1I , Ii1i1iI , IIiI1 in ii :
   try :
    oo0o00OO ( III1ii1I , Ii1i1iI , IIiI1 )
    if 69 - 69: o0000oOoOoO0o % i11iIiiIii / o0oO0
   except :
    pass
    if 93 - 93: iI
 except :
  pass
  if 34 - 34: oO0o0ooO0 - iI * ii11ii1ii / o0000oOoOoO0o
  if 19 - 19: o00O0oo
  if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
def oo0o00OO ( thumb , name , url ) :
 if 66 - 66: O0
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 52 - 52: OoOO * OoooooooOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIIII1iIIii ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
   iiI ( name , url , 4 , OO0O0o0o0 , oo00 )
   if 81 - 81: i1I111II1I * o00O0oo + II111iiii % i1I111II1I
  else :
   if 46 - 46: II111iiii % O0ooOooooO - i1IIi / O0oO * OoOO0ooOOoo0O
   iiI ( name , url , 4 , OO0O0o0o0 , oo00 )
   if 92 - 92: ii11ii1ii - Oooo0Ooo000
def IIi11 ( name , url , thumb , id , trailer ) :
 if 73 - 73: iI + o00O0oo
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 100 - 100: iIii1I11I1II1
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIIII1iIIii ( name , url , '' , o00 , oo00 )
 else :
  oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 77 - 77: II111iiii + o0000oOoOoO0o
  name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
  if 47 - 47: IIII
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if IIIi1I1IIii1II == 'true' :
    if 75 - 75: i1I111II1I % i11iIiiIii + iIii1I11I1II1
    oOoOo0o00o ( name , url , 1 , thumb , thumb , id , trailer )
    if 2 - 2: II111iiii
   else :
    if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
    oOoOo0o00o ( name , url , 130 , thumb , thumb , id , trailer )
    if 22 - 22: IIII
  else :
   if 22 - 22: O0ooOooooO * O0oO - ii11ii1ii * O0 / i11iIiiIii
   if IIIi1I1IIii1II == 'true' :
    if 78 - 78: ii11ii1ii * O0 / iI + OoooooooOO + IIII
    oOoOo0o00o ( name , url , 1 , thumb , thumb , id , trailer )
    if 23 - 23: O0ooOooooO % OoooooooOO / iIii1I11I1II1 + o00O0oo / i1IIi / o0000oOoOoO0o
   else :
    if 94 - 94: i1IIi
    oOoOo0o00o ( name , url , 130 , thumb , thumb , id , trailer )
    if 36 - 36: OOooOOo + ii11ii1ii
    if 46 - 46: O0ooOooooO
def O00OoOO0oo0 ( name , url , thumb , id , trailer , description , fanart ) :
 if 65 - 65: i1IIi . o00O0oo / iI
 if 11 - 11: i1I111II1I * iI / iI - IIII
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
 if 68 - 68: OOooOOo % i1I111II1I - i1I111II1I / OOooOOo + o00O0oo - ii11ii1ii
 if 'tvg-logo' in thumb :
  thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if IIIi1I1IIii1II == 'true' :
   if 65 - 65: iI - i1IIi
   O00Oo ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 38 - 38: i1IIi . i11iIiiIii
  else :
   if 93 - 93: O0oO * II111iiii / o0oO0 - o0000oOoOoO0o
   O00Oo ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 98 - 98: i11iIiiIii / OOooOOo * o0000oOoOoO0o / Oooo0Ooo000
 else :
  if 67 - 67: O0oO % oO0o0ooO0
  if IIIi1I1IIii1II == 'true' :
   if 39 - 39: i11iIiiIii + i1I111II1I
   O00Oo ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 7 - 7: iIii1I11I1II1 - i1IIi
  else :
   if 10 - 10: Oooo0Ooo000 % O0 / OOooOOo % O0oO
   O00Oo ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 25 - 25: II111iiii / OoOO
   if 64 - 64: O0 % iI
   if 40 - 40: o0000oOoOoO0o + O0oO
def OoO000Oo0oO ( name , trailer ) :
 if 46 - 46: O0 - OoOO0ooOOoo0O . OoooooooOO
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 19 - 19: o0000oOoOoO0o
  IIiI1 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  o00OOOOOo0OOo = IIiI1
  i1II11I11ii1 = xbmcgui . ListItem ( name , trailer , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
 else :
  IIiI1 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  o00OOOOOo0OOo = IIiI1
  i1II11I11ii1 = xbmcgui . ListItem ( name , trailer , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
  if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
  if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
def iIIiI11iI1Ii1 ( name , url ) :
 if 94 - 94: iI / i11iIiiIii % O0
 if i1Oo00 == 'true' :
  if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
  try :
   if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
   O0Oooo = xbmcgui . DialogProgress ( )
   O0Oooo . create ( 'Realstream:' , 'Iniciando ...' )
   O0Oooo . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   O0Oooo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   O0Oooo . close ( )
   if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
   o00OOOOOo0OOo = url
   i1II11I11ii1 = xbmcgui . ListItem ( name , i1iI1 , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   if 68 - 68: O0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 76 - 76: o00O0oo
 else :
  if 99 - 99: o0000oOoOoO0o
  try :
   if 1 - 1: o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
   O0Oooo = xbmcgui . DialogProgress ( )
   O0Oooo . create ( 'Realstream:' , 'Iniciando ...' )
   O0Oooo . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   O0Oooo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   O0Oooo . close ( )
   if 90 - 90: Oooo0Ooo000 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
   o00OOOOOo0OOo = url
   i1II11I11ii1 = xbmcgui . ListItem ( name , i1iI1 , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   if 89 - 89: oO0o0ooO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 87 - 87: O0ooOooooO % ii11ii1ii
 return
 if 62 - 62: OoOO + iI / O0ooOooooO * i11iIiiIii
 if 37 - 37: O0ooOooooO
def iIIiI1111 ( trailer ) :
 if 91 - 91: OoooooooOO / o0000oOoOoO0o . i1I111II1I - iIii1I11I1II1 - o0oO0
 if 'https://www.youtube.com' in trailer :
  if 31 - 31: i1I111II1I - OoOO / IIII . i1IIi / o0oO0
  try :
   if 66 - 66: OoOO
   import resolveurl
   if 72 - 72: Oooo0Ooo000
   o00ooo = urlresolver . HostedMediaFile ( IIiI1 )
   O0Oooo = xbmcgui . DialogProgress ( )
   O0Oooo . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   O0Oooo . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 91 - 91: II111iiii / i1I111II1I + iIii1I11I1II1 . O0oO - O0
   if not o00ooo :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 70 - 70: o0oO0 * oO0o0ooO0 - O0oO + ii11ii1ii % o00O0oo - i1I111II1I
   try :
    if 81 - 81: O0 . O0
    O0Oooo . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iIIi1iI1I1IIi = o00ooo . resolve ( )
    if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
     try : O0OO0 = iIIi1iI1I1IIi . msg
     except : O0OO0 = iIIi1iI1I1IIi
     raise Exception ( O0OO0 )
   except Exception as IiIi1ii111i1 :
    try : O0OO0 = str ( IiIi1ii111i1 )
    except : O0OO0 = iIIi1iI1I1IIi
    O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    O0Oooo . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
   O0Oooo . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   O0Oooo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   O0Oooo . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   O0Oooo . close ( )
   if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 40 - 40: iIii1I11I1II1 + O0ooOooooO * OoOO0ooOOoo0O + oO0o0ooO0
  except :
   pass
   if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * iI
  else :
   if 71 - 71: OoOO0ooOOoo0O % ii11ii1ii % iI
   IIiI1 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   o00OOOOOo0OOo = IIiI1
   i1II11I11ii1 = xbmcgui . ListItem ( trailer , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   return
   if 34 - 34: O0oO / O0oO % i1I111II1I . OoOO0ooOOoo0O / ii11ii1ii
def O0OO000OOo0o ( name , url ) :
 if 86 - 86: o0oO0 . O0ooOooooO - O0ooOooooO
 if '[Youtube]' in name :
  if 71 - 71: iIii1I11I1II1 . II111iiii % iIii1I11I1II1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  o00OOOOOo0OOo = url
  i1II11I11ii1 = xbmcgui . ListItem ( i1iI1 , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
  if 22 - 22: i11iIiiIii % o00O0oo % iI % iI . OoOO
  if 85 - 85: iI . O0 / IIII * iI - OoOO - i11iIiiIii
 else :
  if 25 - 25: iI % ii11ii1ii - IIII
  import urlresolver
  from urlresolver import common
  if 80 - 80: i1I111II1I % II111iiii - ii11ii1ii - iIii1I11I1II1
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 9 - 9: o0000oOoOoO0o % o00O0oo . o00O0oo
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 28 - 28: OoooooooOO % oO0o0ooO0 + o00O0oo + O0 . Oooo0Ooo000
   if 80 - 80: i11iIiiIii % o00O0oo
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as IiIi1ii111i1 :
   try : O0OO0 = str ( IiIi1ii111i1 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iI % i1I111II1I
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 19 - 19: o00O0oo / iIii1I11I1II1 % i1IIi . OoooooooOO
  if 57 - 57: iI . ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0000oOoOoO0o
 return
 if 79 - 79: o00O0oo + o0000oOoOoO0o % ii11ii1ii * o0000oOoOoO0o
def iiii11IiIiI ( name , url ) :
 if 8 - 8: Oooo0Ooo000 + OoOO
 import resolveurl
 if 9 - 9: IIII + o0000oOoOoO0o
 o00ooo = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 8 - 8: IIII * ii11ii1ii / O0ooOooooO - OoOO - OoooooooOO
 if not o00ooo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
 try :
  if 55 - 55: oO0o0ooO0
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  iIIi1iI1I1IIi = o00ooo . resolve ( )
  if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
   try : O0OO0 = iIIi1iI1I1IIi . msg
   except : O0OO0 = iIIi1iI1I1IIi
   raise Exception ( O0OO0 )
 except Exception as IiIi1ii111i1 :
  try : O0OO0 = str ( IiIi1ii111i1 )
  except : O0OO0 = iIIi1iI1I1IIi
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 37 - 37: i1I111II1I / i11iIiiIii / ii11ii1ii
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
 if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 if 90 - 90: ii11ii1ii * OOooOOo
def iiii11IiIiI ( name , url ) :
 if 75 - 75: o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . OoooooooOO - ii11ii1ii . O0oO
 if 6 - 6: O0oO * oO0o0ooO0 / OoooooooOO % o0oO0 * o0000oOoOoO0o
 if 'https://www.rapidvideo.com/v/' in url :
  if 28 - 28: i1I111II1I * OOooOOo % i1I111II1I
  iiI1I1 = ooO ( url )
  ii = re . compile ( 'rapidvideo' ) . findall ( iiI1I1 )
  for url in ii :
   if 95 - 95: O0 / O0oO . Oooo0Ooo000
   if 17 - 17: O0oO
   try :
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 56 - 56: iI * o0000oOoOoO0o + O0oO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 48 - 48: i1I111II1I * OoOO % Oooo0Ooo000 - O0oO
   if 72 - 72: i1IIi % iI % i1I111II1I % oO0o0ooO0 - oO0o0ooO0
 else :
  if 97 - 97: o0000oOoOoO0o * O0 / o0000oOoOoO0o * OoOO * ii11ii1ii
  import urlresolver
  from urlresolver import common
  if 38 - 38: Oooo0Ooo000
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: oO0o0ooO0 * O0ooOooooO
   if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as IiIi1ii111i1 :
   try : O0OO0 = str ( IiIi1ii111i1 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 36 - 36: i1I111II1I
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 19 - 19: OoOO0ooOOoo0O . o0000oOoOoO0o . OoooooooOO
 return
 if 13 - 13: IIII . ii11ii1ii / II111iiii
 if 43 - 43: iIii1I11I1II1 % OoOO
 if 84 - 84: ii11ii1ii
def iiiiI11iiIIi ( name , url ) :
 if 43 - 43: O0oO % o0oO0 / o0000oOoOoO0o * Oooo0Ooo000
 iIIi1iI1I1IIi = url
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 else :
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 return
 if 85 - 85: iIii1I11I1II1 . OoooooooOO . o0000oOoOoO0o
def oO00OoO0oo ( name , url ) :
 if 52 - 52: i1I111II1I % iI
 if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
 if '[Youtube]' in name :
  if 23 - 23: i11iIiiIii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 65 - 65: II111iiii / ii11ii1ii
    if 42 - 42: i11iIiiIii . O0
    if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
  if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
 else :
  if 92 - 92: O0oO / O0 * OOooOOo - O0oO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 99 - 99: i11iIiiIii % OoooooooOO
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 56 - 56: i1I111II1I * Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 98 - 98: O0oO + O0 * Oooo0Ooo000 + i11iIiiIii - IIII - iIii1I11I1II1
  import resolveurl as urlresolver
  if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
  if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 56 - 56: i1IIi . i11iIiiIii
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as IiIi1ii111i1 :
   try : O0OO0 = str ( IiIi1ii111i1 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 15 - 15: II111iiii * oO0o0ooO0 % O0ooOooooO / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
   if 9 - 9: O0oO - oO0o0ooO0 + O0 / O0ooOooooO % i1IIi
   if 97 - 97: o0000oOoOoO0o * iI
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 78 - 78: O0oO . IIII + oO0o0ooO0 * O0ooOooooO - i1IIi
   if '[Realstream]' in name :
    if 27 - 27: o0oO0 % i1IIi . ii11ii1ii % Oooo0Ooo000
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 73 - 73: OoooooooOO . ii11ii1ii / O0 - O0
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 25 - 25: iIii1I11I1II1 * O0oO - oO0o0ooO0 % i11iIiiIii + o0oO0 % oO0o0ooO0
   if 5 - 5: iIii1I11I1II1 . oO0o0ooO0
   if 2 - 2: iIii1I11I1II1 * OOooOOo % i1IIi % o00O0oo + OoooooooOO + OOooOOo
 return
 if 16 - 16: IIII
 if 63 - 63: O0ooOooooO
 if 11 - 11: O0ooOooooO - iIii1I11I1II1
def ooOo0O0 ( name , url ) :
 if 83 - 83: OoooooooOO
 if 12 - 12: iI
 if '[Youtube]' in name :
  if 36 - 36: Oooo0Ooo000 . i1I111II1I * OoooooooOO - o0000oOoOoO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 60 - 60: IIII . O0ooOooooO / iIii1I11I1II1 + IIII * Oooo0Ooo000
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - O0oO + o0oO0
    if 48 - 48: o00O0oo
    if 96 - 96: iI . OoooooooOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 39 - 39: IIII + OoOO
 else :
  if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
  import resolveurl
  if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 71 - 71: iI . i11iIiiIii
  if 56 - 56: O0 * O0ooOooooO + O0ooOooooO * iIii1I11I1II1 / iI * Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 25 - 25: iIii1I11I1II1 . O0oO * i11iIiiIii + ii11ii1ii * O0oO
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as IiIi1ii111i1 :
   try : O0OO0 = str ( IiIi1ii111i1 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 67 - 67: O0ooOooooO
   if 88 - 88: ii11ii1ii
   if 8 - 8: o00O0oo
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 82 - 82: OoooooooOO
   if 'uptostream.com' or 'uptobox.com' in url :
    if 75 - 75: II111iiii % OOooOOo + IIII % OoooooooOO / i1I111II1I
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 71 - 71: iI . iI - iIii1I11I1II1
   if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
   if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
 return
 if 61 - 61: II111iiii . O0 - o0oO0 - o00O0oo / i11iIiiIii - II111iiii
def O0oo0oOo ( name , url ) :
 if 40 - 40: O0oO % iI
 if 71 - 71: OoOO
 if '[Youtube]' in name :
  if 75 - 75: O0ooOooooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 16 - 16: o00O0oo + II111iiii * OoOO0ooOOoo0O . i1I111II1I
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 10 - 10: O0ooOooooO * o0oO0 - iI . O0oO - IIII
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 94 - 94: OOooOOo % i1I111II1I + OoOO
 else :
  if 90 - 90: i1IIi + O0 - oO0o0ooO0 . O0ooOooooO + iIii1I11I1II1
  if 'https://team.com' in url :
   if 88 - 88: o0oO0 * O0 . Oooo0Ooo000 / OoooooooOO
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 29 - 29: OoooooooOO . II111iiii % OoOO0ooOOoo0O
   if 26 - 26: iIii1I11I1II1 - o00O0oo . i1I111II1I . i1I111II1I + iIii1I11I1II1 * ii11ii1ii
  if 'https://drive.com' in url :
   if 85 - 85: IIII + II111iiii - IIII * oO0o0ooO0 - i1IIi % O0ooOooooO
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 1 - 1: OoooooooOO / O0 + OoOO0ooOOoo0O + OoOO0ooOOoo0O . Oooo0Ooo000 - OoOO0ooOOoo0O
  if 'https://vid.co' in url :
   if 9 - 9: Oooo0Ooo000 * OoooooooOO % OOooOOo / OoOO0ooOOoo0O * O0oO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 48 - 48: OoooooooOO . OoOO0ooOOoo0O
  if 'https://limited.to' in url :
   if 65 - 65: oO0o0ooO0 . ii11ii1ii
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 94 - 94: OoOO0ooOOoo0O + i1I111II1I . iI
  import resolveurl
  if 69 - 69: O0 - O0
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 41 - 41: i1I111II1I % o0000oOoOoO0o
  if 67 - 67: O0 % Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as IiIi1ii111i1 :
   try : O0OO0 = str ( IiIi1ii111i1 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 39 - 39: o0oO0
   if 60 - 60: IIII
   if 62 - 62: Oooo0Ooo000 * O0oO
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 74 - 74: OoOO0ooOOoo0O . iIii1I11I1II1
    if 'uptostream.com' or 'uptobox.com' in url :
     iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 87 - 87: iI
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 41 - 41: OoOO0ooOOoo0O . iIii1I11I1II1 % iI + O0
 return
 if 22 - 22: o0000oOoOoO0o + ii11ii1ii . iI + o00O0oo * O0ooOooooO . i11iIiiIii
 if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
def OoO ( name , url ) :
 if 18 - 18: ii11ii1ii - IIII * II111iiii + oO0o0ooO0
 if 'mybox.com' in url :
  if 93 - 93: O0ooOooooO * oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 59 - 59: II111iiii
  try :
   if 43 - 43: ii11ii1ii + OoooooooOO
   iiI1I1 = ooO ( url )
   ii = re . compile ( oOO0O00oO0Ooo ) . findall ( iiI1I1 )
   for url , i1I111iIii1i1 , o0Oo in ii :
    if 16 - 16: O0ooOooooO % OOooOOo - iI
    i1I111iIii1i1 = i1I111iIii1i1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + i1I111iIii1i1 + '[/COLOR] - [COLOR gold]' + o0Oo + '[/COLOR]'
    if 100 - 100: OoooooooOO * oO0o0ooO0
    OoO0o0OO = [ ]
    OoO0o0OO . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    OoO0o0OO . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    OoO0o0OO . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 10 - 10: oO0o0ooO0 - O0ooOooooO % II111iiii - Oooo0Ooo000 - i1IIi
    if 10 - 10: o00O0oo - O0oO . Oooo0Ooo000
    iiIIIi1iIi = 'Seleccione una calidad e idioma:'
    i1iI = xbmcgui . Dialog ( )
    OOo0OOOoOOo = i1iI . select ( iiIIIi1iIi , OoO0o0OO )
    if 29 - 29: OoOO0ooOOoo0O . O0ooOooooO + OoOO0ooOOoo0O + O0 . O0 * IIII
    if 38 - 38: O0ooOooooO * OoooooooOO
    if 2 - 2: oO0o0ooO0 - i11iIiiIii
    if OOo0OOOoOOo == 0 :
     if 98 - 98: oO0o0ooO0 + OoooooooOO - Oooo0Ooo000 % i11iIiiIii / o0000oOoOoO0o . OoooooooOO
     iii11 = i1iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1iI
     return
     if 87 - 87: i1IIi
    elif OOo0OOOoOOo == 1 :
     if 33 - 33: Oooo0Ooo000 % II111iiii
     pass
     if 49 - 49: o00O0oo + O0oO / o0000oOoOoO0o + OoooooooOO + IIII / i1I111II1I
     del i1iI
     if 29 - 29: o0oO0 - o0oO0 / iI
     if 49 - 49: O0oO + oO0o0ooO0 % OoOO - ii11ii1ii - O0 - OoooooooOO
    elif OOo0OOOoOOo == 2 :
     if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
     iIIiI11iI1Ii1 ( name , url )
     if 18 - 18: ii11ii1ii % O0
     return
     if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
  except :
   pass
   if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
 elif 'uptostream.com' in url :
  if 86 - 86: i1I111II1I
  try :
   if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
   iiI1I1 = ooO ( url )
   ii = re . compile ( oOO0O00oO0Ooo ) . findall ( iiI1I1 )
   for url , i1I111iIii1i1 , o0Oo in ii :
    if 33 - 33: II111iiii - i1I111II1I - iI
    i1I111iIii1i1 = i1I111iIii1i1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + i1I111iIii1i1 + '[/COLOR] [COLOR gold]Idioma: ' + o0Oo + '[/COLOR]'
    if 92 - 92: OoOO * i1I111II1I
    OoO0o0OO = [ ]
    OoO0o0OO . append ( '[COLOR white]Reiniciar calidades disponibles[/COLOR]' )
    OoO0o0OO . append ( '[COLOR white]Otras calidades e idiomas[/COLOR]' )
    OoO0o0OO . append ( '[COLOR white]Ver en: %s ' % name )
    if 92 - 92: oO0o0ooO0
    if 7 - 7: O0ooOooooO
    iiIIIi1iIi = 'Seleccione una calidad e idioma:'
    i1iI = xbmcgui . Dialog ( )
    OOo0OOOoOOo = i1iI . select ( iiIIIi1iIi , OoO0o0OO )
    if 73 - 73: OoOO % o00O0oo
    if 32 - 32: IIII + O0ooOooooO + iIii1I11I1II1 * ii11ii1ii
    if OOo0OOOoOOo == 0 :
     if 62 - 62: i11iIiiIii
     iii11 = i1iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1iI
     return
     if 2 - 2: OOooOOo
    elif OOo0OOOoOOo == 1 :
     if 69 - 69: OoooooooOO / ii11ii1ii * Oooo0Ooo000
     pass
     if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * oO0o0ooO0 / II111iiii % OoooooooOO
     del i1iI
     if 14 - 14: i1I111II1I . i1I111II1I % iI
     if 42 - 42: o0000oOoOoO0o . IIII - iI
     if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
     if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
    elif OOo0OOOoOOo == 2 :
     if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
     iIIiI11iI1Ii1 ( name , url )
     if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
     return
     if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
  except :
   pass
 else :
  if 6 - 6: oO0o0ooO0 . O0oO
  O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  iiI1I1 = ooO ( oOO0O00Oo0O0o )
  ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
  for iIi11ii in ii :
   if 43 - 43: o00O0oo + o0000oOoOoO0o
   try :
    if 50 - 50: oO0o0ooO0 % i1IIi * O0
    if 4 - 4: iIii1I11I1II1 . i1IIi
    O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
    if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
    if O00O0oOO00O00 == iIi11ii :
     if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
     if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
     if 'https://team.com' in url :
      if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 99 - 99: ii11ii1ii + i11iIiiIii
     if 'https://mybox.com' in url :
      if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 98 - 98: iIii1I11I1II1 - i1IIi + iI % O0oO + iI / oO0o0ooO0
      if 97 - 97: i1I111II1I % iI + II111iiii - i1I111II1I % OoOO + iI
     if 'https://vidcloud.co/' in url :
      if 31 - 31: o0000oOoOoO0o
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iI / OoOO0ooOOoo0O
     if 'https://gounlimited.to' in url :
      if 69 - 69: iI . IIII - OOooOOo
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
     if 'https://drive.com' in url :
      if 26 - 26: i1I111II1I / o0oO0 - OoooooooOO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 9 - 9: OoooooooOO * o00O0oo
      if 9 - 9: ii11ii1ii + O0ooOooooO
     import resolveurl
     if 64 - 64: O0 * OOooOOo / OOooOOo
     o00ooo = urlresolver . HostedMediaFile ( url )
     if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
     if not o00ooo :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
     try :
      if 72 - 72: OoOO + i11iIiiIii + o00O0oo
      O0Oooo = xbmcgui . DialogProgress ( )
      O0Oooo . create ( 'Realstream:' , 'Iniciando ...' )
      O0Oooo . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
      iIIi1iI1I1IIi = o00ooo . resolve ( )
      if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
       if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
       try : O0OO0 = iIIi1iI1I1IIi . msg
       except : O0OO0 = url
       raise Exception ( O0OO0 )
       if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
     except Exception as IiIi1ii111i1 :
      try : O0OO0 = str ( IiIi1ii111i1 )
      except : O0OO0 = url
      if 10 - 10: OOooOOo + O0
      if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
      if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
      for oOiI1I in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       i111I1 = 1
       O0Oooo . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oOiI1I )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % i111I1 )
       O0Oooo . close ( )
       if 69 - 69: OoOO - OoooooooOO - IIII % O0oO / OoOO0ooOOoo0O - II111iiii
      for oOiI1I in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       i111I1 = 2
       O0Oooo . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oOiI1I )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % i111I1 )
       O0Oooo . close ( )
      for oOiI1I in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       i111I1 = 3
       O0Oooo . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oOiI1I )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % i111I1 )
       O0Oooo . close ( )
      for oOiI1I in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       i111I1 = 4
       O0Oooo . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oOiI1I )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % i111I1 )
       O0Oooo . close ( )
      for oOiI1I in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       i111I1 = 5
       O0Oooo . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oOiI1I )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % i111I1 )
       O0Oooo . close ( )
       if 67 - 67: IIII + IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
      if O0Oooo . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       O0Oooo . close ( )
       break
       if 31 - 31: oO0o0ooO0 * Oooo0Ooo000 . OoOO0ooOOoo0O * O0oO
       if 28 - 28: i1I111II1I + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
       if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
     O0Oooo . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     O0Oooo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     O0Oooo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     O0Oooo . close ( )
     i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
     ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
     if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - i1I111II1I . OoooooooOO
     if 10 - 10: Oooo0Ooo000
    else :
     if 48 - 48: O0ooOooooO * i1IIi % OoooooooOO * o0oO0 * OoOO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
   except :
    pass
    if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
 return
 if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
 if 55 - 55: OoooooooOO
 if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
 if 38 - 38: O0
def ooOi1i1i11iI11II ( ) :
 if 6 - 6: OoOO0ooOOoo0O . II111iiii * OOooOOo . OOooOOo / o0oO0
 I1I1ii1111 = [ ]
 IIIiI1iiiIIIi = sys . argv [ 2 ]
 if len ( IIIiI1iiiIIIi ) >= 2 :
  OoO000Oo00 = sys . argv [ 2 ]
  iI1 = OoO000Oo00 . replace ( '?' , '' )
  if ( OoO000Oo00 [ len ( OoO000Oo00 ) - 1 ] == '/' ) :
   OoO000Oo00 = OoO000Oo00 [ 0 : len ( OoO000Oo00 ) - 2 ]
  oOoo = iI1 . split ( '&' )
  I1I1ii1111 = { }
  for oOiI1I in range ( len ( oOoo ) ) :
   o00O0o00oo = { }
   o00O0o00oo = oOoo [ oOiI1I ] . split ( '=' )
   if ( len ( o00O0o00oo ) ) == 2 :
    I1I1ii1111 [ o00O0o00oo [ 0 ] ] = o00O0o00oo [ 1 ]
 return I1I1ii1111
 if 19 - 19: OOooOOo
 if 66 - 66: oO0o0ooO0 / OoOO0ooOOoo0O
def iII1I ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 92 - 92: Oooo0Ooo000 % o0oO0
def Ii1Ii11I ( ) :
 i1iI = xbmcgui . Dialog ( )
 list = (
 i1io0o00O ,
 iiiI1ii
 )
 if 61 - 61: ii11ii1ii * i1IIi . OoooooooOO
 iIIiI = i1iI . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oo00O00oO ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 90 - 90: O0ooOooooO * o0oO0 - O0ooOooooO + OoOO + O0oO % O0
 if iIIiI :
  if 11 - 11: IIII % Oooo0Ooo000 * OoOO0ooOOoo0O
  if iIIiI < 0 :
   return
  OoO00oo0 = list [ iIIiI - 2 ]
  return OoO00oo0 ( )
 else :
  OoO00oo0 = list [ iIIiI ]
  return OoO00oo0 ( )
 return
 if 96 - 96: i1IIi
def oOOO00 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 61 - 61: o00O0oo
iIII = oOOO00 ( )
if 97 - 97: i1IIi * Oooo0Ooo000 . II111iiii
def i1io0o00O ( ) :
 if iIII == 'android' :
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O00oOoo0OoO0 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 62 - 62: OoooooooOO . o0oO0
  if 28 - 28: oO0o0ooO0 . oO0o0ooO0 . iIii1I11I1II1 . IIII . o00O0oo * i11iIiiIii
def iiiI1ii ( ) :
 if 72 - 72: O0oO
 main ( )
 if 26 - 26: i1I111II1I % ii11ii1ii
 if 72 - 72: O0 + o0000oOoOoO0o + OOooOOo / ii11ii1ii
 if 83 - 83: i1I111II1I - OOooOOo . o0oO0
def iI1Iii11i ( ) :
 i1iI = xbmcgui . Dialog ( )
 O0OOOo0o = (
 ooo0oOOOO00Oo ,
 Ii1iii1
 )
 if 37 - 37: iIii1I11I1II1 % O0oO / i1I111II1I
 iIIiI = i1iI . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 37 - 37: Oooo0Ooo000 - oO0o0ooO0 - OoOO
 if iIIiI :
  if 42 - 42: iIii1I11I1II1 % o0oO0 - o00O0oo + iIii1I11I1II1
  if iIIiI < 0 :
   return
  OoO00oo0 = O0OOOo0o [ iIIiI - 2 ]
  return OoO00oo0 ( )
 else :
  OoO00oo0 = O0OOOo0o [ iIIiI ]
  return OoO00oo0 ( )
 return
 if 27 - 27: O0 / OoOO
def oOOO00 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 99 - 99: o0oO0 - i1I111II1I * iIii1I11I1II1 . II111iiii
iIII = oOOO00 ( )
if 56 - 56: iIii1I11I1II1 % OoOO . iI % i1I111II1I . Oooo0Ooo000 * ii11ii1ii
def ooo0oOOOO00Oo ( ) :
 if iIII == 'android' :
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O00oOoo0OoO0 = webbrowser . open ( 'https://olpair.com/' )
  if 41 - 41: iIii1I11I1II1 % i1I111II1I * oO0o0ooO0 - iI
  if 5 - 5: OoOO + OoOO + II111iiii * iIii1I11I1II1 + OoooooooOO
def Ii1iii1 ( ) :
 if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
 main ( )
 if 10 - 10: o00O0oo + i1I111II1I
 if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
def oooO0 ( name , url , id , trailer ) :
 i1iI = xbmcgui . Dialog ( )
 O0OOOo0o = (
 I11Iii11i11I1 ,
 IiOO0oo00OOo ,
 OoOo00oOoO ,
 Ii1Ii11I ,
 Oo0O00o0O0
 )
 if 4 - 4: iIii1I11I1II1 . Oooo0Ooo000 + II111iiii % OoooooooOO
 iIIiI = i1iI . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oo00O00oO ] )
 if 82 - 82: OoooooooOO / iI * O0oO * O0 . o00O0oo
 if iIIiI :
  if 21 - 21: II111iiii + ii11ii1ii
  if iIIiI < 0 :
   return
  OoO00oo0 = O0OOOo0o [ iIIiI - 5 ]
  return OoO00oo0 ( )
 else :
  OoO00oo0 = O0OOOo0o [ iIIiI ]
  return OoO00oo0 ( )
 return
 if 59 - 59: IIII + OOooOOo / II111iiii / OoOO0ooOOoo0O
 if 80 - 80: OoOO0ooOOoo0O + iIii1I11I1II1 . i1I111II1I
 if 76 - 76: OOooOOo * IIII
def I11Iii11i11I1 ( ) :
 if 12 - 12: iIii1I11I1II1 / O0oO % o0oO0
 OoO ( Ii1i1iI , IIiI1 )
 if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
def IiOO0oo00OOo ( ) :
 if 27 - 27: OoOO + ii11ii1ii
 OoO000Oo0oO ( Ii1i1iI , i1iI1 )
 if 92 - 92: OOooOOo % O0ooOooooO
def OoOo00oOoO ( ) :
 if 31 - 31: OoooooooOO - oO0o0ooO0 / Oooo0Ooo000
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oo00o000O = id
  if 66 - 66: OoooooooOO + o0000oOoOoO0o . i1IIi * O0ooOooooO
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oo00o000O )
  if 92 - 92: O0oO / Oooo0Ooo000
 if i1Oo00 == 'true' :
  if 4 - 4: Oooo0Ooo000
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii1i1iI + "[/COLOR] ,5000)" )
  if 11 - 11: OoooooooOO + i1IIi / o0oO0
def i1I ( ) :
 if 14 - 14: O0 / O0oO . OoOO % O0ooOooooO . oO0o0ooO0
 Ii1Ii11I ( )
 if 16 - 16: OoooooooOO % OOooOOo - o0000oOoOoO0o / II111iiii . i1IIi
def Oo0O00o0O0 ( ) :
 if 27 - 27: II111iiii + iI . OoOO0ooOOoo0O - Oooo0Ooo000
 O0iIi1IiII ( )
def iIIII1iIIii ( name , url , mode , iconimage , fanart ) :
 if 54 - 54: OoOO0ooOOoo0O . ii11ii1ii
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  IIo0OoO00 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
  return iii11
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 38 - 38: i1IIi . ii11ii1ii * ii11ii1ii / o00O0oo
def iIIiI1I1i ( name , url , mode , iconimage , fanart , description ) :
 if 65 - 65: iI % O0
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 17 - 17: i1IIi + oO0o0ooO0 . O0oO + i1IIi - II111iiii % OOooOOo
def iIIi1 ( name , url , mode , iconimage ) :
 if 76 - 76: OOooOOo - OOooOOo - o0000oOoOoO0o % iI * O0
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , oo00 )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 11 - 11: o0oO0 + O0oO . OoOO . i11iIiiIii * OoOO
 if 18 - 18: O0oO + ii11ii1ii - OoOO / Oooo0Ooo000 / IIII
def oOoOo0o00o ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 52 - 52: Oooo0Ooo000 + Oooo0Ooo000
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OO0 = [ ]
 if 1 - 1: O0 . OOooOOo * OoooooooOO
 OO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 if 70 - 70: O0 / OoooooooOO + o00O0oo + i1IIi
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 63 - 63: O0ooOooooO / o00O0oo * oO0o0ooO0 / II111iiii + IIII - O0
  IIIIIiII1 . addContextMenuItems ( OO0 , replaceItems = True )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 16 - 16: II111iiii / o0oO0 . o0oO0 - o0oO0 / o00O0oo
 if 28 - 28: IIII * OoooooooOO + iI % O0ooOooooO . iIii1I11I1II1
def O00Oo ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 17 - 17: i1I111II1I / o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 39 - 39: o0000oOoOoO0o / i1I111II1I - O0ooOooooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OO0 = [ ]
 if 96 - 96: O0oO * o00O0oo * o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
 OO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 if 37 - 37: O0oO % o00O0oo / iI
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
  IIIIIiII1 . addContextMenuItems ( OO0 , replaceItems = True )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 1 - 1: ii11ii1ii . II111iiii
def iiI ( name , url , mode , iconimage , fanart ) :
 if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 4 - 4: i1I111II1I
def IiI1iIiiI1iI ( name , url , mode , iconimage ) :
 if 2 - 2: OOooOOo * Oooo0Ooo000 % Oooo0Ooo000 - Oooo0Ooo000 - O0ooOooooO + IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 7 - 7: O0oO - OoOO . OoooooooOO / OoooooooOO - O0oO
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , oo00 )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 84 - 84: II111iiii
def i1IIii1i ( name , url , mode , iconimage ) :
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 60 - 60: o0oO0 % ii11ii1ii / O0oO . O0ooOooooO / Oooo0Ooo000 - OoooooooOO
def o0iii1i ( ) :
 if 30 - 30: OoOO0ooOOoo0O / OOooOOo - OoOO - O0ooOooooO - i11iIiiIii
 if 84 - 84: i1IIi - OOooOOo % O0ooOooooO
 if 80 - 80: o0000oOoOoO0o % O0ooOooooO
 Oo00o0OO0O00o = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 Oo00o0OO0O00o . doModal ( )
 if ( Oo00o0OO0O00o . isConfirmed ( ) ) :
  if 80 - 80: o0oO0
  I1ii11 = urllib . quote_plus ( Oo00o0OO0O00o . getText ( ) ) . replace ( '+' , ' ' )
  if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 59 - 59: o00O0oo + O0oO . oO0o0ooO0
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % I1ii11 )
    if 87 - 87: OoOO
    if i1Oo00 == 'true' :
     if 34 - 34: Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii1i1iI + "[/COLOR] ,10000)" )
     if 46 - 46: ii11ii1ii + II111iiii * OOooOOo + IIII
   except :
    if 31 - 31: o0oO0 * o0000oOoOoO0o * o0oO0 + OoOO * o0000oOoOoO0o . Oooo0Ooo000
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 89 - 89: OoooooooOO * o0oO0 * OOooOOo . iI * o0oO0 / O0ooOooooO
OoO000Oo00 = ooOi1i1i11iI11II ( )
IIiI1 = None
Ii1i1iI = None
iioo = None
OO0O0o0o0 = None
id = None
i1iI1 = None
if 21 - 21: i1IIi
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 69 - 69: OoOO0ooOOoo0O + OoOO0ooOOoo0O + IIII % IIII * O0oO % o0oO0
try :
 IIiI1 = urllib . unquote_plus ( OoO000Oo00 [ "url" ] )
except :
 pass
try :
 Ii1i1iI = urllib . unquote_plus ( OoO000Oo00 [ "name" ] )
except :
 pass
try :
 iioo = int ( OoO000Oo00 [ "mode" ] )
except :
 pass
try :
 OO0O0o0o0 = urllib . unquote_plus ( OoO000Oo00 [ "iconimage" ] )
except :
 pass
try :
 id = int ( OoO000Oo00 [ "id" ] )
except :
 pass
try :
 i1iI1 = urllib . unquote_plus ( OoO000Oo00 [ "trailer" ] )
except :
 pass
 if 10 - 10: o0oO0
 if 14 - 14: O0ooOooooO * OoOO % O0 + O0oO + o00O0oo
print "Mode: " + str ( iioo )
print "URL: " + str ( IIiI1 )
print "Name: " + str ( Ii1i1iI )
print "iconimage: " + str ( OO0O0o0o0 )
print "id: " + str ( id )
print "trailer: " + str ( i1iI1 )
if 23 - 23: ii11ii1ii % O0ooOooooO + o0oO0 - Oooo0Ooo000
if 65 - 65: OoooooooOO
def oO0Oo0O0o ( ) :
 if 22 - 22: IIII + II111iiii + ii11ii1ii
 try :
  if 83 - 83: iI
  import urlresolver
  from urlresolver import common
  import random
  from random import choice
  i1Ii1i11ii = xbmc . Player ( )
  Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
  oO0O0oo = random . choice ( Oo0O0O0ooO0O )
  IIiI1 = 'https://www.youtube.com/watch?v=%s' % oO0O0oo
  IIiI1 = urlresolver . HostedMediaFile ( IIiI1 ) . resolve ( )
  i1Ii1i11ii . play ( IIiI1 )
  if 64 - 64: OoOO0ooOOoo0O % OoOO0ooOOoo0O + o0000oOoOoO0o + ii11ii1ii
  OO0oO0Oo == 'false'
  if 82 - 82: i11iIiiIii + iIii1I11I1II1 / ii11ii1ii + IIII * II111iiii
 except :
  pass
  if 34 - 34: o0000oOoOoO0o % OoooooooOO
  if 36 - 36: OOooOOo
  if 64 - 64: i11iIiiIii + i1IIi % O0 . O0oO
if iioo == None or IIiI1 == None or len ( IIiI1 ) < 1 :
 if 64 - 64: iI / i1IIi % O0ooOooooO
 if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . iI . i1I111II1I - ii11ii1ii
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiI1I1 = ooO ( oOO0O00Oo0O0o )
 ii = re . compile ( Ii1I1Ii ) . findall ( iiI1I1 )
 for iIi11ii in ii :
  if 99 - 99: Oooo0Ooo000
  try :
   if 75 - 75: iI . IIII / i1I111II1I
   if 84 - 84: OoooooooOO . OOooOOo / o0000oOoOoO0o
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 86 - 86: ii11ii1ii % OoOO0ooOOoo0O
   if 77 - 77: o0oO0 % IIII / oO0o0ooO0
   if O00O0oOO00O00 == iIi11ii :
    if 91 - 91: OoOO / OoOO . II111iiii . iI - OOooOOo
    O0iIi1IiII ( )
    I11i1iIiIIIIIii ( )
    if 23 - 23: OOooOOo
    OO0oO0Oo = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if OO0oO0Oo == 'true' :
     xbmc . sleep ( 2000 )
     oO0Oo0O0o ( )
     if 7 - 7: O0ooOooooO % o00O0oo
   else :
    if 64 - 64: Oooo0Ooo000 + i11iIiiIii
    oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    iIIII1iIIii ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 35 - 35: OoOO0ooOOoo0O + i1IIi % IIII
  except :
   pass
   if 68 - 68: i1I111II1I . iI
elif iioo == 1 :
 oooO0 ( Ii1i1iI , IIiI1 , id , i1iI1 )
elif iioo == 2 :
 i1IIi1i1Ii1 ( )
elif iioo == 3 :
 O000oOo ( )
elif iioo == 4 :
 O0OO000OOo0o ( Ii1i1iI , IIiI1 )
elif iioo == 5 :
 Ii11iii1II1i ( )
elif iioo == 6 :
 OOOo ( )
elif iioo == 7 :
 Ooo0OiiII1IiIi1iI1 ( )
elif iioo == 8 :
 oO0o ( )
elif iioo == 9 :
 oOO0 ( )
elif iioo == 10 :
 o00OoooooooOo ( )
elif iioo == 11 :
 iIi11i ( )
elif iioo == 12 :
 Iii ( )
elif iioo == 13 :
 I1ii1 ( )
elif iioo == 14 :
 oOo0Oo0O0O ( )
elif iioo == 15 :
 OOOoo ( )
elif iioo == 16 :
 I1ii1i ( )
elif iioo == 17 :
 oOooo00000 ( )
elif iioo == 18 :
 o0OO00oo0O ( )
elif iioo == 19 :
 o0O00Oooo ( )
elif iioo == 20 :
 iI111II1ii ( )
elif iioo == 21 :
 I111I1I ( )
elif iioo == 22 :
 ii1IIiII111I ( )
elif iioo == 23 :
 o0OOOOOo0 ( )
elif iioo == 24 :
 I1IiII1I1i1I1 ( )
elif iioo == 25 :
 oooOo ( )
elif iioo == 26 :
 IiI1i111IiIiIi1 ( )
elif iioo == 28 :
 Ii1IIi ( Ii1i1iI , IIiI1 )
elif iioo == 29 :
 iI11Ii111 ( )
elif iioo == 30 :
 O0o00o000oO ( )
elif iioo == 31 :
 prueba ( )
elif iioo == 98 :
 busqueda_global ( )
elif iioo == 97 :
 iI1Iii11i ( )
elif iioo == 99 :
 I11i1iIiiIiIi ( )
elif iioo == 100 :
 menu_player ( Ii1i1iI , IIiI1 )
elif iioo == 111 :
 OOOO0O00o ( )
elif iioo == 115 :
 OoO000Oo0oO ( IIiI1 )
elif iioo == 116 :
 Ooo0O ( )
elif iioo == 117 :
 iIII1i1i ( )
elif iioo == 119 :
 OOOOooO0oO00O0o ( )
elif iioo == 120 :
 i11i1iIiii ( )
elif iioo == 121 :
 I1i1i ( )
elif iioo == 125 :
 IIiiI ( )
elif iioo == 112 :
 list_proxy ( )
elif iioo == 127 :
 o0iii1i ( )
elif iioo == 128 :
 TESTLINKS ( )
elif iioo == 130 :
 OoO ( Ii1i1iI , IIiI1 )
elif iioo == 140 :
 OoOo000oOo0oo ( )
elif iioo == 141 :
 Ii1I1i1ii1I1 ( )
elif iioo == 142 :
 I111I11I111 ( )
elif iioo == 143 :
 ooOOOOo0 ( Ii1i1iI , IIiI1 )
elif iioo == 144 :
 Ii1IIi ( Ii1i1iI , IIiI1 )
elif iioo == 145 :
 OOO0ooo ( )
elif iioo == 150 :
 oo0OOOoOo ( )
elif iioo == 151 :
 IiI ( )
elif iioo == 152 :
 iIIIi1i1I11i ( )
elif iioo == 155 :
 oOoOOOo ( )
 if 64 - 64: i1IIi + ii11ii1ii * OOooOOo / IIII
 if 3 - 3: ii11ii1ii / iI + iI . o00O0oo
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
