#Script por Han Solo para Han Solo Wizard
import xbmc
xbmc.executebuiltin("RunAddon(plugin.video.palantir)", True)
xbmc.executebuiltin("ActivateWindow(home)", True)
xbmc.executebuiltin("ReloadSkin()", True)
xbmc.executebuiltin("Notification(Bienvenido a Han Solo Wizard)", True)