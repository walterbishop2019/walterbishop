# -*- coding: utf-8 -*-

# estadepelis clon de solocastellano, orientado a latino

from channels.solocastellano import *
