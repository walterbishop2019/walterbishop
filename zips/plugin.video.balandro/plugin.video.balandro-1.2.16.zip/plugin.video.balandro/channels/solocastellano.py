# -*- coding: utf-8 -*-

import re, base64

from platformcode import config, logger
from core.item import Item
from core import httptools, scrapertools, servertools, tmdb

IDIOMAS = {'Castellano': 'Esp', 'Latino': 'Lat', 'Sub Español': 'VOSE'}

def detectar_host(canal):
    return 'http://www.estadepelis.com/' if canal == 'estadepelis' else 'http://solocastellano.com/'


def mainlist(item):
    return mainlist_pelis(item)

def mainlist_pelis(item):
    logger.info()
    itemlist = []
    host = detectar_host(item.channel)
    
    itemlist.append(item.clone( title='Estrenos', action='lista', url=host ))
    itemlist.append(item.clone( title='Lista de películas', action='lista', url=host + 'lista-de-peliculas/' ))
    itemlist.append(item.clone( title='Lista de documentales', action='lista', url=host + 'lista-de-documentales/' ))
    itemlist.append(item.clone( title='Por Género', action='generos' ))
    itemlist.append(item.clone( title='Por Año', action='anyos' ))

    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'movie' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []
    host = detectar_host(item.channel)

    data = httptools.downloadpage(host).data
    data = scrapertools.find_single_match(data, '<ul class="generos">(.*?)</ul>')
    
    patron = '<a href="([^"]+)"[^>]*>([^<]+)'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        itemlist.append(item.clone( action='lista', url=host + scrapedurl, title=scrapedtitle ))

    return itemlist


def anyos(item):
    logger.info()
    itemlist = []
    host = detectar_host(item.channel)

    data = httptools.downloadpage(host).data
    data = scrapertools.find_single_match(data, '<ul class="scrolling years">(.*?)</ul>')
    
    patron = 'HREF="([^"]+)">([^<]+)'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        itemlist.append(item.clone( action='lista', url=host + scrapedurl, title=scrapedtitle ))

    return itemlist


def lista(item):
    logger.info()
    itemlist = []
    host = detectar_host(item.channel)

    data = httptools.downloadpage(item.url).data

    patron = '<div class="movie">\s*<div class="imagen">\s*<img src="([^"]+)" alt="([^"]+)".*?<a href=(?:\'|")([^\'"]+)(?:\'|").*?<span class="year">([^<]*)'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedthumbnail, scrapedtitle, scrapedurl, scrapedyear in matches:

        itemlist.append(item.clone( action = 'findvideos', title = scrapedtitle, url = host + scrapedurl,
                                    contentType = 'movie', contentTitle = scrapedtitle,
                                    thumbnail = scrapedthumbnail, infoLabels = {'year': scrapedyear} ))

    tmdb.set_infoLabels(itemlist)

    # Paginación
    next_page = scrapertools.find_single_match(data, '<div class="siguiente"><a href="([^"]+)')
    if next_page != '':
        if next_page[0] == '/': next_page = next_page[1:]
        itemlist.append(item.clone( title='Página siguiente >>', url=host + next_page, action='lista' ))

    return itemlist



def resolve_src(src, var_e20f, host):
    src = src.replace('(', '').replace(')', '')
    src = src.replace('ef5ca18f089cf01316bbc967fa10f72950790c39ef5ca18f089cf01316bbc967fa10f72950790c39', 'http://tawnestdplsnetps.fun/')
    src = src.replace('b48699bb49d4550f27879deeb948d4f7d9c5949a8', 'embed')
    src = src.replace('JzewJkLlrvcFnLelj2ikbA', 'php?url=')
    if 'solocastellano' in host:
        src = src.replace('p889c6853a117aca83ef9d6523335dc065213ae86', 'castplayer')
    else:
        src = src.replace('p889c6853a117aca83ef9d6523335dc065213ae86', 'player')
    src = src.replace('e20fb341325556c0fc0145ce10d08a970538987', var_e20f)
    src = src.replace('+', '').replace("'", '').replace('"', '')
    return src


def findvideos(item):
    logger.info()
    itemlist = []
    host = detectar_host(item.channel)

    data = httptools.downloadpage(item.url).data
    # ~ logger.debug(data)
    
    var_e20f = scrapertools.find_single_match(data, 'var e20fb341325556c0fc0145ce10d08a970538987 = ([^;]+)')
    if not var_e20f: return itemlist
    var_e20f = resolve_src(var_e20f, '', host)
    # ~ logger.debug(var_e20f)

    patron = "function play(\d+)\(\) \{ \$\('#servidores'\)\.attr\('src',(.*?)\); \}"
    matches = re.compile(patron, re.DOTALL).findall(data)
    # ~ logger.debug(matches)
    for num, src in matches:
        decoded = resolve_src(src, var_e20f, host)
        # ~ logger.debug('%s Src: %s Decoded: %s' % (num, src, decoded))

        lang = scrapertools.find_single_match(data, '<a onclick="return play'+num+'\(\);"> ([^<]+)</a>').strip()
        
        if 'php?url=' in decoded: continue #TODO ...

        itemlist.append(Item(channel = item.channel, action = 'play',
                             title = '', url = decoded, server = 'netutv',
                             language = IDIOMAS.get(lang, lang)
                       ))

    return itemlist


def resolve_id(vid):
    s2 = ''
    for i in range(0, len(vid), 3):
        s2 += '\u0' + vid[i:i+3]
    return s2.decode('unicode-escape')

def play(item):
    logger.info()
    itemlist = []

    if item.url.startswith('http://tawnestdplsnetps.fun/'): 
        data = httptools.downloadpage(item.url).data
        # ~ logger.debug(data)
        
        var_id = scrapertools.find_single_match(data, 'id="([^"]+)')

        decoded = scrapertools.find_single_match(resolve_id(var_id), '"v":"([^"]+)')
        if decoded:
            url = 'http://netu.tv/watch_video.php?v=' + decoded
            itemlist.append(item.clone(url = url))
    
    return itemlist


def findvideos_ant(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    logger.debug(data)

    patron = '<a href="http://www\.solocastellano\.com/enlaces\.php\?url=([^"]+)'
    patron += '.*? alt="([^"]*)"'
    patron += '.*?<span class="c">([^<]*)</span>'
    patron += '\s*<span class="d">([^<]*)</span>'
    matches = re.compile(patron, re.DOTALL).findall(data)
    logger.debug(matches)

    for surl, stitle, slang, squality in matches:

        surl = surl.replace('%3D', '=')
        if '&player=1' in surl:
            surl = surl.replace('&player=1', '')
            other = ''
        else:
            other = 'descarga'
            continue # descartar descargas directas !?

        url = base64.b64decode(surl)
        language = IDIOMAS[slang] if slang in IDIOMAS else slang

        if url not in [it.url for it in itemlist]:
            itemlist.append(Item(channel = item.channel, action = 'play',
                                 title = stitle, url = url,
                                 language = language, quality = squality, other = other
                           ))

    itemlist = servertools.get_servers_itemlist(itemlist)

    return itemlist


def search(item, texto):
    logger.info()
    host = detectar_host(item.channel)
    
    item.url = host + 'search?q=' + texto.replace(" ", "+")
    try:
        return lista(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
