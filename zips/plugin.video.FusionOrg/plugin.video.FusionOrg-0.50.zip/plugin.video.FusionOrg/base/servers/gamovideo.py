# -*- coding: utf-8 -*-
import json
import re
import urllib

from base import jsunpack
import requests
import xbmcgui


headers = {}
headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'
headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
headers['Accept-Encoding'] = 'deflate'


def read2(url, cookies_=''):
    data = 'Imposible conectar con el server'
    location = ''
    cookies = ''
    try:
        if cookies_ != '':
            response = requests.get(
                url, headers=headers, timeout=10, cookies=cookies_)
        else:
            response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.content
            location = response.headers.get('location')
            cookies = response.cookies
    except:
        pass
    return data, location, cookies


def urlgamovideo(url):
    if 'embed-' in url:
        id_gamo = re.findall('embed-(.*?).html', url, re.I)
        if len(id_gamo) > 0:
            id_gamo = id_gamo[0]
        else:
            id_gamo = ''
            url = url.replace('embed-', '')
    if not 'embed-' in url:
        id_gamo = re.findall('/(.*?).html', url, re.I)
        if len(id_gamo) > 0:
            id_gamo = id_gamo[0]
        else:
            id_gamo = re.findall('\/\/.*?\/(.*)', url, re.I)[0]
            if len(id_gamo) > 0:
                id_gamo = id_gamo[0]
            else:
                id_gamo = ''
    if id_gamo != '':
        source, location, cookies = read2(
            'http://gamovideo.com/{}.html'.format(id_gamo))
    else:
        source, location, cookies = read2(url)

    if id_gamo != '':
        source, location, cookies = read2(
            'http://gamovideo.com/{}.html'.format(id_gamo), cookies_=cookies)
    else:
        source, location, cookies = read2(url, cookies_=cookies)

    error = ''
    if 'Imposible conectar con el server' in source:
        error = 'Imposible conectar con el server'
    if 'File was deleted' in source or 'File Not Found' in source or 'File was locked by administrator' in source:
        error = 'El archivo no existe o ha sido borrado'
    if 'Video is processing now' in source:
        error = 'El video está procesándose en estos momentos. Inténtelo mas tarde.'
    if 'File is awaiting for moderation' in source:
        error = 'El video está esperando por moderación.'
    if error != '':
        dialog = xbmcgui.Dialog()
        dialog.notification('FusionOrg', 'Fallo: ' + error,
                            xbmcgui.NOTIFICATION_INFO, 5000, True)
        exit()


    source = re.sub('(\r){1,}', '', source)
    source = re.sub('(\n){1,}', '', source)
    source = re.sub('(\t){1,}', '', source)
    source = re.sub('(\s){1,}', ' ', source)
    jspack = re.findall(
        "<script type='text/javascript'>(eval.function.p,a,c,k,e,d..*?)</script>", source, re.IGNORECASE)
    source = jsunpack.unpack(jspack[0])

    finalurlgamo = re.findall('file:"(http.*?mp4)"', source, re.IGNORECASE)[0]
    header_test = {
        'user-agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}
    header_test = '|' + urllib.urlencode(header_test)
    return finalurlgamo + header_test
