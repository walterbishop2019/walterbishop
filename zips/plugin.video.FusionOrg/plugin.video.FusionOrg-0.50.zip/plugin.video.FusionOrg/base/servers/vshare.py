import os
import re
import urllib
import urlparse

from base import jsunpack
from resources.lib.conector import conect
import requests
import xbmc
import xbmcaddon
import xbmcgui


addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addon_dir = xbmc.translatePath(xbmc.translatePath(
    addon.getAddonInfo('Path')).decode('utf-8'))

data_path = xbmc.translatePath(addon.getAddonInfo('Profile'))
if not os.path.exists(data_path):
    os.makedirs(data_path)

icon = os.path.join(addon_dir, 'icon.png')


default_headers = dict()
default_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36'
default_headers['Referer'] = 'https://vshare.io/'


def test_vshare(url):
    response = conect.get_url(url, h=default_headers)
    if response != 'Imposible conectar con el server':
        if response.status_code == 200 and not ('No longer available!' in response.content or '404 - Error' in response.content or "Can't find the resource" in response.content):
            return True, response.content
    return False, 'Imposible conectar con el server'

# def calidades_vshare(url):


def vshare(url):
    calidad = ''
    if 'calidad' in url:
        calidad = urlparse.parse_qs(url)['calidad'][0]
        url = url.split('&')[0]
    url = url.replace('/d/', '/v/')
    if not 'width' in url and not 'height' in url:
        if not url.endswith('/'):
            url = url + '/width-470/height-305/'
        else:
            url = url + 'width-470/height-305/'
    calidades = []
    finallinks = []
    valid, data = test_vshare(url)
    if valid:
        jspack = re.findall(
            "(eval.function.p,a,c,k,e,d.*?)\n", data, re.IGNORECASE)
        if len(jspack) > 0:
            unpack = jsunpack.unpack(jspack[0]).split(';')
            charcodes = [int(val) for val in unpack[1].split(
                '=')[-1].replace('[', '').replace(']', '').split(',')]
            sub = int(''.join(char for char in unpack[2].split(
                '-')[1] if char.isdigit()))
            charcodes = [val - sub for val in charcodes]
            srcs = ''.join(map(unichr, charcodes))
            data = data.replace(jspack[0], srcs)

        c = re.findall("<source\s*(.*?)>", data, re.IGNORECASE)
        if calidad == '':
            for x in c:
                calidades += [re.findall('res=\"(\d*)\"', x, re.I)[0]]
            return True, calidades
        else:
            finallink = ''
            for x in c:
                if calidad == re.findall('res=\"(\d*)\"', x, re.I)[0]:
                    finallink = re.findall(
                        'src=\"(.*?)\"', x, re.I)[0] + '|' + urllib.urlencode(default_headers)
            if finallink == '':
                finallink = re.findall(
                    'source.*?src=\"(.*?)\"', data, re.I)[0] + '|' + urllib.urlencode(default_headers)
            return True, finallink
    return False, 'VShare fallo!!!'
