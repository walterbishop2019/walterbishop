# -*- coding: utf-8 -*-
import cookielib
import re
import urllib
import urllib2


def test_video(url):
    data = read(url)
    if 'We’re Sorry!' in data:
        data = read(url.replace("/embed/", "/f/"))
        if 'We’re Sorry!' in data:
            return False, "[Openload] El archivo no existe o ha sido borrado"
    return True, ""


def get_video_openload(url):
    data = read(url)
    server = 'openload.co'
    if 'oload.stream' in url:
        server = 'oload.stream'
    if 'openload.co' in url:
        server = 'openload.co'
    if 'oload.tv' in url:
        server = 'oload.tv'
    try:
        try:
            code = re.findall(
                '<p id="[^"]+" style="">(.*?)</p>', data, flags=re.DOTALL)[0]
        except:
            code = re.findall(
                '<p style="" id="[^"]+">(.*?)</p>', data, flags=re.DOTALL)[0]
        _0x59ce16 = eval(re.findall(
            '_0x59ce16=([^;]+)', data)[0].replace('parseInt', 'int'))
        _1x4bfb36 = eval(re.findall(
            '_1x4bfb36=([^;]+)', data)[0].replace('parseInt', 'int'))
        parseInt = eval(re.findall('_0x30725e,(\(parseInt.*?)\),',
                                   data)[0].replace('parseInt', 'int'))
        url = decode(code, parseInt, _0x59ce16, _1x4bfb36, server)
        if not 'mime=true' in url:
            url = url + 'mime=true'
        url2 = read_openload(url)
        if url2 != '':
            url = url2
        else:
            return ''
    except:
        pass
        return ''

    header_test = {
        'user-agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36'}
    header_test = '|' + urllib.urlencode(header_test)
    try:
        url = url.encode('utf-8')
    except:
        pass

    return url + header_test


def read(url):
    opener = urllib2.build_opener()
    opener.addheaders = [
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36')]
    response = opener.open(url)
    data = response.read()
    return data


def read_openload(url):
    default_headers = dict()
    default_headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36"
    default_headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
    default_headers["Accept-Language"] = "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3"
    default_headers["Accept-Charset"] = "UTF-8"
    default_headers["Accept-Encoding"] = "gzip"
    cj = cookielib.MozillaCookieJar()
    request_headers = default_headers.copy()
    url = urllib.quote(url, safe="%/:=&?~#+!$,;'@()*[]")
    handlers = [urllib2.HTTPHandler(debuglevel=False)]
    handlers.append(NoRedirectHandler())
    handlers.append(urllib2.HTTPCookieProcessor(cj))
    opener = urllib2.build_opener(*handlers)
    req = urllib2.Request(url, None, request_headers)
    handle = opener.open(req, timeout=None)

    return handle.headers.dict.get('location')


def decode(code, parseInt, _0x59ce16, _1x4bfb36, server):
    import math

    _0x1bf6e5 = ''
    ke = []

    for i in range(0, len(code[0:9 * 8]), 8):
        ke.append(int(code[i:i + 8], 16))

    _0x439a49 = 0
    _0x145894 = 0

    while _0x439a49 < len(code[9 * 8:]):
        _0x5eb93a = 64
        _0x896767 = 0
        _0x1a873b = 0
        _0x3c9d8e = 0
        while True:
            if _0x439a49 + 1 >= len(code[9 * 8:]):
                _0x5eb93a = 143

            _0x3c9d8e = int(code[9 * 8 + _0x439a49:9 * 8 + _0x439a49 + 2], 16)
            _0x439a49 += 2

            if _0x1a873b < 6 * 5:
                _0x332549 = _0x3c9d8e & 63
                _0x896767 += _0x332549 << _0x1a873b
            else:
                _0x332549 = _0x3c9d8e & 63
                _0x896767 += int(_0x332549 * math.pow(2, _0x1a873b))

            _0x1a873b += 6
            if not _0x3c9d8e >= _0x5eb93a:
                break

        # _0x30725e = _0x896767 ^ ke[_0x145894 % 9] ^ _0x59ce16 ^ parseInt ^ _1x4bfb36
        _0x30725e = _0x896767 ^ ke[_0x145894 % 9] ^ parseInt ^ _1x4bfb36
        _0x2de433 = _0x5eb93a * 2 + 127

        for i in range(4):
            _0x3fa834 = chr(((_0x30725e & _0x2de433) >> (9 * 8 / 9) * i) - 1)
            if _0x3fa834 != '$':
                _0x1bf6e5 += _0x3fa834
            _0x2de433 = (_0x2de433 << (9 * 8 / 9))

        _0x145894 += 1

    url = "https://%s/stream/%s?" % (server, _0x1bf6e5)
    return url


class NoRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl

    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

#=========================================================================
# Example
# print get_video_openload('https://openload.co/embed/0dN7dAFdPSI/Bad_Romance_-_03.mp4')
#=========================================================================
